# Инструкция для Claude Code: Интеграция нового UI/UX в проект Ashgate

Данный файл содержит исчерпывающее техническое задание и спецификацию для автоматического переноса разработанного интерфейса вкладки «Приложения» и сайдбара в репозиторий **Ashgate** (десктопный проксификатор для Windows 10/11 на Go + `go-webview2` + WinDivert).

---

## 1. Контекст архитектуры Ashgate

- **Язык и ядро:** Go 1.25+, сборка без CGO (`CGO_ENABLED=0 GOOS=windows GOARCH=amd64 go build -trimpath -ldflags "-s -w -H windowsgui" -o dist/ashgate.exe ./cmd/ashgate`).
- **Драйвер перехвата:** WinDivert 2.2.2 (перехват TCP/UDP на уровне сокетов и сети по PID).
- **Оконная подсистема:** Microsoft Edge WebView2 через библиотеку `go-webview2`.
- **Разрешение и адаптивность окна:**
  - Базовый размер окна: 1100×720 DIP.
  - Минимальный размер: 760×520 DIP.
  - Брейкпоинт адаптивности сайдбара: при ширине окна `< 920px` сайдбар сворачивается в иконочную рейку.
- **Хранение конфигурации:** `%ProgramData%\Ashgate\config.json` (или `%AppData%\Ashgate\config.json`).

---

## 2. Формат данных `config.json`

В файле `config.json` секция правил имеет следующий вид:
```json
{
  "version": 1,
  "relay": { "tcp4": "127.0.0.1:34010", "tcp6": "[::1]:34010" },
  "dns": {
    "mode": "proxy",
    "servers": ["1.1.1.1:53", "8.8.8.8:53"],
    "includeSystemResolver": false,
    "systemResolverProxy": ""
  },
  "bypassPrivate": false,
  "udpUnsupported": "block",
  "log": { "file": "", "level": "info" },
  "proxies": [
    { "name": "local", "type": "socks5", "address": "127.0.0.1:1080", "username": "", "password": "" },
    { "name": "vless-de", "type": "vless", "address": "203.0.113.10:443", "link": "vless://..." }
  ],
  "rules": [
    { 
      "enabled": true, 
      "process": "Telegram.exe", 
      "action": "proxy", 
      "proxy": "vless-de",
      "children": true,
      "killSwitch": true
    },
    { 
      "enabled": true, 
      "process": "chrome.exe", 
      "action": "direct", 
      "proxy": "",
      "children": true
    }
  ]
}
```

### Соответствие полей (`AppRule` в TS ↔ `config.json` в Go)

| Поле в TypeScript (`src/App.tsx`) | Поле в `config.json` | Тип | Описание |
|-----------------------------------|----------------------|-----|----------|
| `processName` | `process` | `string` | Имя исполняемого файла (`Telegram.exe`) или полный путь |
| `name` | Вычисляется на клиенте | `string` | Имя процесса без `.exe` для чистого отображения (`Telegram`) |
| `enabled` | `enabled` | `bool` | Включено/выключено правило |
| `action` | `action` | `string` | `"proxy"`, `"direct"` или `"block"` |
| `proxyId` | `proxy` | `string` | Имя прокси (пустая строка для `direct` и `block`) |
| `proxyChildren` | `children` | `bool` | Наследование правила дочерними процессами приложения |
| `killSwitch` | `killSwitch` | `bool` | Блокировка утечек через Windows Firewall |

---

## 3. Что реализовано в новом интерфейсе (`src/App.tsx`)

1. **Минималистичный сайдбар с нативным статусом:**
   - Отображение статуса: светящийся индикатор (`Работает` / `Остановлен`).
   - Крупная тактильная кнопка `Стоп` (в активном режиме с микро-бликом) / `Запустить` (в неактивном режиме, акцентная оранжевая).
   - При ширине `< 920px` сайдбар автоматически трансформируется в компактный иконочный режим.

2. **Вкладка «Приложения»:**
   - Заголовок с описанием и быстрыми действиями (`Поиск по процессам...`, `Из запущенных окон`, `+ Добавить`).
   - Номера правил, иконки приложений, названия процессов строго **без `.exe`** (`Discord`, `Telegram`, `Cursor`).
   - Полноценная функция **группировки правил**:
     - Чекбоксы в начале строки для выбора нескольких правил.
     - Плавающая панель группировки при выборе («Сгруппировать правила»).
     - Сворачивание/разворачивание группы, общий тумблер активности и единый выбор прокси на заголовке группы.
     - Отдельные правила внутри группы не перегружены лишними плашками (все наследуется от группы).
     - Разгруппировка вынесена в меню `⋯`.
   - Выравнивание телеметрии: столбец потоков и скорости строго выровнен по вертикали (`w-[240px]`).
   - Модальное окно добавления приложения с автоподтягиванием пути к `.exe` и красивыми чекбоксами.

---

## 4. Задачи для Claude Code по внедрению в Go

### 1. Интеграция статики
- Скомпилировать фронтенд (`npm run build`).
- Скопировать папку `dist/` в директорию веб-ресурсов Go (например, `internal/ui/assets/`).
- Использовать стандартную директиву `//go:embed all:assets` для вшивания статики в бинарник `ashgate.exe`.

### 2. Подключение Go IPC (двусторонняя связь)
В коде инициализации `go-webview2` зарегистрировать следующие биндинги:

```go
// 1. Сохранение правил в config.json
w.Bind("saveRules", func(rulesJSON string) error {
    return app.SaveRules(rulesJSON)
})

// 2. Переключение состояния ядра WinDivert
w.Bind("toggleEngine", func(enable bool) (bool, error) {
    if enable {
        return true, engine.Start()
    }
    return false, engine.Stop()
})

// 3. Диалог выбора .exe через проводник Windows
w.Bind("selectExecutableDialog", func() string {
    return win32.OpenFileDialog("Исполняемые файлы (*.exe)|*.exe")
})

// 4. Получение списка активных процессов
w.Bind("getRunningProcesses", func() []string {
    return process.ListActiveProcessNames()
})
```

В `src/App.tsx` заменить mock-стейт на вызовы соответствующих методов:
```ts
// Пример:
const handleToggleEngine = async () => {
  if (window.toggleEngine) {
    const newState = await window.toggleEngine(!isEngineRunning);
    setIsEngineRunning(newState);
  }
};
```

### 3. Обновление `scripts/package.ps1`
Добавить сборку фронтенда перед сборкой Go:
```powershell
Push-Location frontend
npm run build
Pop-Location
go build -trimpath -ldflags "-s -w -H windowsgui" -o dist\ashgate.exe .\cmd\ashgate
```
