import React, { useState, useEffect, useMemo } from 'react';
import {
  Home,
  Server,
  Layers,
  Activity,
  Sliders,
  Power,
  Search,
  Plus,
  AppWindow,
  MoreHorizontal,
  Check,
  AlertTriangle,
  Shield,
  Zap,
  Globe,
  Trash2,
  Edit3,
  GitBranch,
  X,
  ChevronDown,
  ChevronRight,
  CheckSquare,
  Square,
  RefreshCw,
  FolderOpen,
  Folder,
  FolderPlus,
  FolderMinus,
  ListChecks,
  Info,
  Download
} from 'lucide-react';

// Types
export type ProxyType = 'VLESS' | 'SOCKS5' | 'DIRECT';

export interface ProxyOption {
  id: string;
  name: string;
  type: ProxyType;
  endpoint: string;
  status: 'online' | 'offline';
  pingMs: number;
}

export interface RuleGroup {
  id: string;
  name: string;
  enabled: boolean;
  isCollapsed: boolean;
  proxyId: string;
}

export interface AppRule {
  id: string;
  name: string;
  processName: string;
  path: string;
  proxyId: string;
  enabled: boolean;
  proxyChildren: boolean;
  killSwitch: boolean;
  protocol: 'TCP_UDP' | 'TCP_ONLY';
  iconType: 'discord' | 'cursor' | 'telegram' | 'spotify' | 'chrome' | 'steam' | 'obsidian' | 'code' | 'generic';
  status: 'active' | 'blocked' | 'inactive';
  threads: number;
  downSpeed: string;
  upSpeed: string;
  totalVolume: string;
  errorReason?: string;
  groupId?: string;
}

export interface RunningWindow {
  pid: number;
  title: string;
  processName: string;
  path: string;
  iconType: 'discord' | 'cursor' | 'telegram' | 'spotify' | 'chrome' | 'steam' | 'obsidian' | 'code' | 'generic';
}

const AVAILABLE_PROXIES: ProxyOption[] = [
  {
    id: 'vless-frankfurt',
    name: 'VLESS · Frankfurt #1',
    type: 'VLESS',
    endpoint: '127.0.0.1:10808',
    status: 'online',
    pingMs: 38,
  },
  {
    id: 'vless-amsterdam',
    name: 'VLESS · Amsterdam #2',
    type: 'VLESS',
    endpoint: '127.0.0.1:10809',
    status: 'online',
    pingMs: 44,
  },
  {
    id: 'socks5-local',
    name: 'SOCKS5 · Local Gateway',
    type: 'SOCKS5',
    endpoint: '127.0.0.1:1080',
    status: 'offline', // Simulated offline to trigger Spotify Kill Switch
    pingMs: 0,
  },
  {
    id: 'direct-bypass',
    name: 'Direct · Напрямую без прокси',
    type: 'DIRECT',
    endpoint: '0.0.0.0:0',
    status: 'online',
    pingMs: 4,
  },
];

const INITIAL_GROUPS: RuleGroup[] = [
  {
    id: 'group-social',
    name: 'Связь и звонки',
    enabled: true,
    isCollapsed: true,
    proxyId: 'vless-frankfurt',
  },
];

const INITIAL_RULES: AppRule[] = [
  {
    id: 'rule-discord',
    name: 'Discord',
    processName: 'Discord',
    path: '*\\Discord\\app-*\\Discord.exe',
    proxyId: 'vless-frankfurt',
    enabled: true,
    proxyChildren: true,
    killSwitch: true,
    protocol: 'TCP_UDP',
    iconType: 'discord',
    status: 'active',
    threads: 18,
    downSpeed: '↓ 2,4 МБ/с',
    upSpeed: '↑ 120 КБ/с',
    totalVolume: '842 МБ',
    groupId: 'group-social',
  },
  {
    id: 'rule-cursor',
    name: 'Cursor',
    processName: 'Cursor',
    path: '*\\Cursor\\Cursor.exe',
    proxyId: 'vless-frankfurt',
    enabled: true,
    proxyChildren: true,
    killSwitch: true,
    protocol: 'TCP_UDP',
    iconType: 'cursor',
    status: 'active',
    threads: 8,
    downSpeed: '↓ 420 КБ/с',
    upSpeed: '↑ 34 КБ/с',
    totalVolume: '210 МБ',
  },
  {
    id: 'rule-telegram',
    name: 'Telegram',
    processName: 'Telegram',
    path: '*\\Telegram Desktop\\Telegram.exe',
    proxyId: 'vless-frankfurt',
    enabled: true,
    proxyChildren: false,
    killSwitch: false,
    protocol: 'TCP_UDP',
    iconType: 'telegram',
    status: 'active',
    threads: 6,
    downSpeed: '↓ 180 КБ/с',
    upSpeed: '↑ 12 КБ/с',
    totalVolume: '1,1 ГБ',
    groupId: 'group-social',
  },
  {
    id: 'rule-spotify',
    name: 'Spotify',
    processName: 'Spotify',
    path: '*\\Spotify\\Spotify.exe',
    proxyId: 'socks5-local',
    enabled: true,
    proxyChildren: true,
    killSwitch: true,
    protocol: 'TCP_UDP',
    iconType: 'spotify',
    status: 'blocked',
    threads: 0,
    downSpeed: '↓ 0 Б/с',
    upSpeed: '↑ 0 Б/с',
    totalVolume: '14,2 МБ',
    errorReason: 'Сбой SOCKS5 шлюза 127.0.0.1:1080 (Таймаут соединения). Сработал Kill Switch: сетевой трафик изолирован.',
  },
  {
    id: 'rule-chrome',
    name: 'Chrome',
    processName: 'Chrome',
    path: '*\\Google\\Chrome\\Application\\chrome.exe',
    proxyId: 'vless-frankfurt',
    enabled: false,
    proxyChildren: true,
    killSwitch: true,
    protocol: 'TCP_UDP',
    iconType: 'chrome',
    status: 'inactive',
    threads: 0,
    downSpeed: '—',
    upSpeed: '—',
    totalVolume: '2,8 ГБ',
  },
  {
    id: 'rule-steam',
    name: 'Steam',
    processName: 'Steam',
    path: '*\\Steam\\steam.exe',
    proxyId: 'vless-frankfurt',
    enabled: false,
    proxyChildren: true,
    killSwitch: false,
    protocol: 'TCP_ONLY',
    iconType: 'steam',
    status: 'inactive',
    threads: 0,
    downSpeed: '—',
    upSpeed: '—',
    totalVolume: '540 МБ',
  },
];

const KNOWN_APPS: Record<string, { name: string; path: string; iconType: AppRule['iconType'] }> = {
  discord: { name: 'Discord', path: '*\\Discord\\app-*\\Discord.exe', iconType: 'discord' },
  telegram: { name: 'Telegram', path: '*\\Telegram Desktop\\Telegram.exe', iconType: 'telegram' },
  cursor: { name: 'Cursor', path: '*\\Cursor\\Cursor.exe', iconType: 'cursor' },
  spotify: { name: 'Spotify', path: '*\\Spotify\\Spotify.exe', iconType: 'spotify' },
  chrome: { name: 'Chrome', path: '*\\Google\\Chrome\\Application\\chrome.exe', iconType: 'chrome' },
  googlechrome: { name: 'Chrome', path: '*\\Google\\Chrome\\Application\\chrome.exe', iconType: 'chrome' },
  steam: { name: 'Steam', path: '*\\Steam\\steam.exe', iconType: 'steam' },
  obsidian: { name: 'Obsidian', path: 'C:\\Users\\User\\AppData\\Local\\Obsidian\\Obsidian.exe', iconType: 'obsidian' },
  code: { name: 'Code', path: 'C:\\Users\\User\\AppData\\Local\\Programs\\Microsoft VS Code\\Code.exe', iconType: 'code' },
  vscode: { name: 'Code', path: 'C:\\Users\\User\\AppData\\Local\\Programs\\Microsoft VS Code\\Code.exe', iconType: 'code' },
  figma: { name: 'Figma', path: 'C:\\Users\\User\\AppData\\Local\\Figma\\Figma.exe', iconType: 'generic' },
  slack: { name: 'Slack', path: 'C:\\Users\\User\\AppData\\Local\\slack\\slack.exe', iconType: 'generic' },
  notion: { name: 'Notion', path: 'C:\\Users\\User\\AppData\\Local\\Programs\\Notion\\Notion.exe', iconType: 'generic' },
  brave: { name: 'Brave', path: '*\\Brave-Browser\\Application\\brave.exe', iconType: 'generic' },
};

const RUNNING_WINDOWS_SAMPLE: RunningWindow[] = [
  {
    pid: 14208,
    title: 'Obsidian — Заметки архитектуры v1.7.7',
    processName: 'Obsidian',
    path: 'C:\\Users\\User\\AppData\\Local\\Obsidian\\Obsidian.exe',
    iconType: 'obsidian',
  },
  {
    pid: 8812,
    title: 'Ashgate.sln — Visual Studio Code',
    processName: 'Code',
    path: 'C:\\Users\\User\\AppData\\Local\\Programs\\Microsoft VS Code\\Code.exe',
    iconType: 'code',
  },
  {
    pid: 9104,
    title: 'Google Chrome — 14 вкладок',
    processName: 'Chrome',
    path: 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
    iconType: 'chrome',
  },
  {
    pid: 19430,
    title: 'Steam Community Hub',
    processName: 'Steam',
    path: 'C:\\Program Files (x86)\\Steam\\steam.exe',
    iconType: 'steam',
  },
  {
    pid: 6290,
    title: 'Desktop UI Kit — Figma',
    processName: 'Figma',
    path: 'C:\\Users\\User\\AppData\\Local\\Figma\\Figma.exe',
    iconType: 'generic',
  },
  {
    pid: 4920,
    title: 'Workspace — Slack',
    processName: 'Slack',
    path: 'C:\\Users\\User\\AppData\\Local\\slack\\slack.exe',
    iconType: 'generic',
  },
];

export default function App() {
  const [activeTab, setActiveTab] = useState<'home' | 'proxies' | 'apps' | 'connections' | 'settings'>('apps');
  const [isEngineRunning, setIsEngineRunning] = useState(true);
  const [rules, setRules] = useState<AppRule[]>(INITIAL_RULES);
  const [groups, setGroups] = useState<RuleGroup[]>(INITIAL_GROUPS);
  const [searchQuery, setSearchQuery] = useState('');
  
  // Interactive UI States - Cursor context menu open initially for immediate inspection
  const [openContextMenuRuleId, setOpenContextMenuRuleId] = useState<string | null>('rule-cursor');
  const [openProxySelectorRuleId, setOpenProxySelectorRuleId] = useState<string | null>(null);
  const [openGroupContextMenuId, setOpenGroupContextMenuId] = useState<string | null>(null);
  const [openGroupProxySelectorId, setOpenGroupProxySelectorId] = useState<string | null>(null);
  
  // Selection & Grouping state
  const [isSelectionMode, setIsSelectionMode] = useState(false);
  const [selectedRuleIds, setSelectedRuleIds] = useState<string[]>([]);
  const [isCreateGroupModalOpen, setIsCreateGroupModalOpen] = useState(false);
  const [newGroupName, setNewGroupName] = useState('');
  const [newGroupProxyId, setNewGroupProxyId] = useState('vless-frankfurt');
  const [isCreateGroupProxyDropdownOpen, setIsCreateGroupProxyDropdownOpen] = useState(false);

  // Modals state
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isRunningWindowsModalOpen, setIsRunningWindowsModalOpen] = useState(false);
  const [editingRule, setEditingRule] = useState<AppRule | null>(null);
  const [isSimulatingLiveTelemetry, setIsSimulatingLiveTelemetry] = useState(true);
  const [windowMaximized, setWindowMaximized] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // New rule form state
  const [newProcessName, setNewProcessName] = useState('');
  const [newPath, setNewPath] = useState('');
  const [newProxyId, setNewProxyId] = useState('vless-frankfurt');
  const [newProxyChildren, setNewProxyChildren] = useState(true);
  const [newKillSwitch, setNewKillSwitch] = useState(true);
  const [newProtocol, setNewProtocol] = useState<'TCP_UDP' | 'TCP_ONLY'>('TCP_UDP');
  const [isAddModalProxyDropdownOpen, setIsAddModalProxyDropdownOpen] = useState(false);
  const [selectedRunningAppPid, setSelectedRunningAppPid] = useState<number | null>(null);

  const selectedModalProxy = AVAILABLE_PROXIES.find((p) => p.id === newProxyId) || AVAILABLE_PROXIES[0];

  // Auto-resolve executable path as user types application name
  const handleProcessNameInputChange = (val: string) => {
    setNewProcessName(val);
    setSelectedRunningAppPid(null);
    const key = val.trim().toLowerCase().replace(/\.exe$/i, '').replace(/[\s_-]+/g, '');
    if (key && KNOWN_APPS[key]) {
      setNewPath(KNOWN_APPS[key].path);
    } else if (val.trim()) {
      const clean = val.trim().replace(/\.exe$/i, '');
      setNewPath(`*\\${clean}\\${clean}.exe`);
    } else {
      setNewPath('');
    }
  };

  // Select an active running window to autofill
  const handleSelectRunningApp = (win: RunningWindow) => {
    setSelectedRunningAppPid(win.pid);
    setNewProcessName(win.processName);
    setNewPath(win.path);
  };

  // Outside click listener for menus
  useEffect(() => {
    const handleGlobalClick = (e: MouseEvent) => {
      const target = e.target as HTMLElement;
      if (!target.closest('.context-menu-container') && !target.closest('.context-menu-trigger')) {
        setOpenContextMenuRuleId(null);
      }
      if (!target.closest('.proxy-selector-container') && !target.closest('.proxy-selector-trigger')) {
        setOpenProxySelectorRuleId(null);
      }
      if (!target.closest('.group-context-menu-container') && !target.closest('.group-context-menu-trigger')) {
        setOpenGroupContextMenuId(null);
      }
      if (!target.closest('.group-proxy-selector-container') && !target.closest('.group-proxy-selector-trigger')) {
        setOpenGroupProxySelectorId(null);
      }
      if (!target.closest('.add-proxy-selector-container')) {
        setIsAddModalProxyDropdownOpen(false);
      }
      if (!target.closest('.create-group-proxy-container')) {
        setIsCreateGroupProxyDropdownOpen(false);
      }
    };
    window.addEventListener('click', handleGlobalClick);
    return () => window.removeEventListener('click', handleGlobalClick);
  }, []);

  // Show temporary toast message
  const triggerToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage((prev) => (prev === msg ? null : prev));
    }, 3500);
  };

  // Subtle live telemetry fluctuation simulation for active rules
  useEffect(() => {
    if (!isSimulatingLiveTelemetry || !isEngineRunning) return;

    const interval = setInterval(() => {
      setRules((prevRules) =>
        prevRules.map((rule) => {
          if (!rule.enabled || rule.status !== 'active') return rule;

          // Realistic jitter
          if (rule.processName === 'Discord' || rule.processName === 'Discord.exe') {
            const jitterDown = (2.2 + Math.random() * 0.5).toFixed(1);
            const jitterUp = Math.floor(100 + Math.random() * 40);
            return {
              ...rule,
              downSpeed: `↓ ${jitterDown.replace('.', ',')} МБ/с`,
              upSpeed: `↑ ${jitterUp} КБ/с`,
            };
          }

          if (rule.processName === 'Cursor' || rule.processName === 'Cursor.exe') {
            const jitterDown = Math.floor(380 + Math.random() * 90);
            const jitterUp = Math.floor(25 + Math.random() * 20);
            return {
              ...rule,
              downSpeed: `↓ ${jitterDown} КБ/с`,
              upSpeed: `↑ ${jitterUp} КБ/с`,
            };
          }

          if (rule.processName === 'Telegram' || rule.processName === 'Telegram.exe') {
            const jitterDown = Math.floor(150 + Math.random() * 60);
            const jitterUp = Math.floor(10 + Math.random() * 10);
            return {
              ...rule,
              downSpeed: `↓ ${jitterDown} КБ/с`,
              upSpeed: `↑ ${jitterUp} КБ/с`,
            };
          }

          return rule;
        })
      );
    }, 2800);

    return () => clearInterval(interval);
  }, [isSimulatingLiveTelemetry, isEngineRunning]);

  // Toggle rule enabled state (moves between Active and Inactive sections)
  const handleToggleRule = (id: string, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    setRules((prev) =>
      prev.map((r) => {
        if (r.id !== id) return r;
        const willBeEnabled = !r.enabled;

        // Determine new status
        let newStatus: 'active' | 'blocked' | 'inactive' = 'inactive';
        let threads = 0;
        let downSpeed = '—';
        let upSpeed = '—';

        if (willBeEnabled) {
          if (r.proxyId === 'socks5-local') {
            newStatus = 'blocked';
            downSpeed = '↓ 0 Б/с';
            upSpeed = '↑ 0 Б/с';
          } else {
            newStatus = 'active';
            threads = r.threads || 8;
            downSpeed = '↓ 1,2 МБ/с';
            upSpeed = '↑ 45 КБ/с';
          }
        }

        return {
          ...r,
          enabled: willBeEnabled,
          status: newStatus,
          threads,
          downSpeed,
          upSpeed,
        };
      })
    );
  };

  // Change rule's assigned proxy
  const handleAssignProxy = (ruleId: string, proxyId: string) => {
    const selectedProxy = AVAILABLE_PROXIES.find((p) => p.id === proxyId);
    setRules((prev) =>
      prev.map((r) => {
        if (r.id !== ruleId) return r;
        const isOffline = selectedProxy?.status === 'offline';
        const newStatus = !r.enabled ? 'inactive' : isOffline ? 'blocked' : 'active';
        return {
          ...r,
          proxyId,
          status: newStatus,
          errorReason: isOffline
            ? `Сбой прокси ${selectedProxy?.endpoint}. Сработал Kill Switch: сетевой трафик изолирован.`
            : undefined,
          downSpeed: isOffline ? '↓ 0 Б/с' : r.downSpeed === '—' ? '↓ 1,2 МБ/с' : r.downSpeed,
          upSpeed: isOffline ? '↑ 0 Б/с' : r.upSpeed === '—' ? '↑ 45 КБ/с' : r.upSpeed,
        };
      })
    );
    setOpenProxySelectorRuleId(null);
    triggerToast(`Прокси для правила обновлен: ${selectedProxy?.name}`);
  };

  // Update specific setting from context menu
  const handleUpdateRuleSetting = (ruleId: string, key: keyof AppRule, value: any) => {
    setRules((prev) =>
      prev.map((r) => {
        if (r.id !== ruleId) return r;
        return { ...r, [key]: value };
      })
    );
  };

  // Delete a rule
  const handleDeleteRule = (ruleId: string) => {
    const rule = rules.find((r) => r.id === ruleId);
    setRules((prev) => prev.filter((r) => r.id !== ruleId));
    setOpenContextMenuRuleId(null);
    triggerToast(`Правило «${rule?.processName}» удалено`);
  };

  // Quick fix for Spotify: switch from broken SOCKS5 to fast VLESS
  const handleFixSpotify = () => {
    setRules((prev) =>
      prev.map((r) => {
        if (r.id !== 'rule-spotify') return r;
        return {
          ...r,
          proxyId: 'vless-frankfurt',
          status: 'active',
          threads: 12,
          downSpeed: '↓ 3,2 МБ/с',
          upSpeed: '↑ 84 КБ/с',
          errorReason: undefined,
        };
      })
    );
    triggerToast('Spotify успешно переключен на VLESS (Франкфурт). Трафик разблокирован!');
  };

  // Toggle selection of a rule for grouping
  const handleToggleRuleSelection = (ruleId: string) => {
    setSelectedRuleIds((prev) =>
      prev.includes(ruleId) ? prev.filter((id) => id !== ruleId) : [...prev, ruleId]
    );
  };

  // Select all currently visible active rules
  const handleSelectAllActive = () => {
    const activeIds = activeRules.map((r) => r.id);
    setSelectedRuleIds(activeIds);
  };

  // Toggle group enabled/disabled state (cascades to all member rules)
  const handleToggleGroup = (groupId: string, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    const group = groups.find((g) => g.id === groupId);
    if (!group) return;
    const willBeEnabled = !group.enabled;

    setGroups((prev) =>
      prev.map((g) => (g.id === groupId ? { ...g, enabled: willBeEnabled } : g))
    );

    // Cascade to member rules
    setRules((prev) =>
      prev.map((r) => {
        if (r.groupId !== groupId) return r;
        let newStatus: 'active' | 'blocked' | 'inactive' = 'inactive';
        let threads = 0;
        let downSpeed = '—';
        let upSpeed = '—';

        if (willBeEnabled) {
          if (r.proxyId === 'socks5-local') {
            newStatus = 'blocked';
            downSpeed = '↓ 0 Б/с';
            upSpeed = '↑ 0 Б/с';
          } else {
            newStatus = 'active';
            threads = r.threads || 6;
            downSpeed = '↓ 1,8 МБ/с';
            upSpeed = '↑ 40 КБ/с';
          }
        }

        return {
          ...r,
          enabled: willBeEnabled,
          status: newStatus,
          threads,
          downSpeed,
          upSpeed,
        };
      })
    );

    triggerToast(
      willBeEnabled
        ? `Группа «${group.name}» включена`
        : `Группа «${group.name}» отключена`
    );
  };

  // Toggle collapse/expand of a group
  const handleToggleGroupCollapse = (groupId: string) => {
    setGroups((prev) =>
      prev.map((g) => (g.id === groupId ? { ...g, isCollapsed: !g.isCollapsed } : g))
    );
  };

  // Ungroup: dissolve group and return all member rules to standalone rules
  const handleUngroup = (groupId: string) => {
    const group = groups.find((g) => g.id === groupId);
    const memberCount = rules.filter((r) => r.groupId === groupId).length;
    setRules((prev) =>
      prev.map((r) => (r.groupId === groupId ? { ...r, groupId: undefined } : r))
    );
    setGroups((prev) => prev.filter((g) => g.id !== groupId));
    setOpenGroupContextMenuId(null);
    triggerToast(
      `Группа «${group?.name || 'Правила'}» разделена (${memberCount} правил возвращены в индивидуальный список)`
    );
  };

  // Assign a proxy to all member rules of a group at once
  const handleAssignGroupProxy = (groupId: string, proxyId: string) => {
    const selectedProxy = AVAILABLE_PROXIES.find((p) => p.id === proxyId);
    setGroups((prev) =>
      prev.map((g) => (g.id === groupId ? { ...g, proxyId } : g))
    );
    setRules((prev) =>
      prev.map((r) => {
        if (r.groupId !== groupId) return r;
        const isOffline = selectedProxy?.status === 'offline';
        const newStatus = !r.enabled ? 'inactive' : isOffline ? 'blocked' : 'active';
        return {
          ...r,
          proxyId,
          status: newStatus,
          errorReason: isOffline
            ? `Сбой прокси ${selectedProxy?.endpoint}. Сработал Kill Switch: сетевой трафик изолирован.`
            : undefined,
          downSpeed: isOffline ? '↓ 0 Б/с' : r.downSpeed === '—' ? '↓ 1,2 МБ/с' : r.downSpeed,
          upSpeed: isOffline ? '↑ 0 Б/с' : r.upSpeed === '—' ? '↑ 45 КБ/с' : r.upSpeed,
        };
      })
    );
    setOpenGroupProxySelectorId(null);
    triggerToast(`Прокси для всех правил группы изменен: ${selectedProxy?.name}`);
  };

  // Remove a single rule from a group (turn it into a standalone rule)
  const handleRemoveRuleFromGroup = (ruleId: string) => {
    const rule = rules.find((r) => r.id === ruleId);
    setRules((prev) =>
      prev.map((r) => (r.id === ruleId ? { ...r, groupId: undefined } : r))
    );
    triggerToast(`Приложение «${rule?.processName}» вынесено из группы`);
  };

  // Delete a group and all its rules
  const handleDeleteGroup = (groupId: string) => {
    const group = groups.find((g) => g.id === groupId);
    setRules((prev) => prev.filter((r) => r.groupId !== groupId));
    setGroups((prev) => prev.filter((g) => g.id !== groupId));
    setOpenGroupContextMenuId(null);
    triggerToast(`Группа «${group?.name}» и её правила удалены`);
  };

  // Create new group from selected rules
  const handleCreateGroupSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newGroupName.trim() || selectedRuleIds.length === 0) return;

    const trimmedName = newGroupName.trim();
    const newGroupId = `group-${Date.now()}`;

    const newGroup: RuleGroup = {
      id: newGroupId,
      name: trimmedName,
      enabled: true,
      isCollapsed: true,
      proxyId: newGroupProxyId,
    };

    setGroups((prev) => [...prev, newGroup]);

    const selectedProxy = AVAILABLE_PROXIES.find((p) => p.id === newGroupProxyId);
    const isOffline = selectedProxy?.status === 'offline';

    setRules((prev) =>
      prev.map((r) => {
        if (!selectedRuleIds.includes(r.id)) return r;
        return {
          ...r,
          groupId: newGroupId,
          proxyId: newGroupProxyId,
          enabled: true,
          status: isOffline ? 'blocked' : 'active',
          errorReason: isOffline
            ? `Сбой прокси ${selectedProxy?.endpoint}. Сработал Kill Switch: сетевой трафик изолирован.`
            : undefined,
        };
      })
    );

    const count = selectedRuleIds.length;
    setSelectedRuleIds([]);
    setIsSelectionMode(false);
    setIsCreateGroupModalOpen(false);
    setNewGroupName('');
    triggerToast(`Группа «${trimmedName}» успешно создана (${count} приложений объединены)`);
  };

  // Add rule submit
  const handleAddRuleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newProcessName.trim()) return;

    const rawName = newProcessName.trim();
    const cleanName = rawName.replace(/\.exe$/i, '');
    const exeFileName = `${cleanName}.exe`;

    const newRule: AppRule = {
      id: `rule-${Date.now()}`,
      name: cleanName,
      processName: cleanName,
      path: newPath.trim() || `*\\${exeFileName}`,
      proxyId: newProxyId,
      enabled: true,
      proxyChildren: newProxyChildren,
      killSwitch: newKillSwitch,
      protocol: newProtocol,
      iconType: cleanName.toLowerCase().includes('discord')
        ? 'discord'
        : cleanName.toLowerCase().includes('cursor')
        ? 'cursor'
        : cleanName.toLowerCase().includes('telegram')
        ? 'telegram'
        : cleanName.toLowerCase().includes('spotify')
        ? 'spotify'
        : cleanName.toLowerCase().includes('chrome')
        ? 'chrome'
        : cleanName.toLowerCase().includes('steam')
        ? 'steam'
        : cleanName.toLowerCase().includes('obsidian')
        ? 'obsidian'
        : cleanName.toLowerCase().includes('code')
        ? 'code'
        : 'generic',
      status: 'active',
      threads: 4,
      downSpeed: '↓ 120 КБ/с',
      upSpeed: '↑ 14 КБ/с',
      totalVolume: '24 МБ',
    };

    setRules([newRule, ...rules]);
    setIsAddModalOpen(false);
    setNewProcessName('');
    setNewPath('');
    triggerToast(`Правило для ${cleanName} добавлено в активные`);
  };

  // Add from running windows modal
  const handleAddFromWindow = (win: RunningWindow) => {
    // Check if rule already exists
    const exists = rules.find((r) => r.processName.toLowerCase() === win.processName.toLowerCase());
    if (exists) {
      if (!exists.enabled) {
        handleToggleRule(exists.id);
        triggerToast(`Правило для ${win.processName} уже существовало и было активировано`);
      } else {
        triggerToast(`Правило для ${win.processName} уже активно`);
      }
      setIsRunningWindowsModalOpen(false);
      return;
    }

    const cleanWindowProcessName = win.processName.replace(/\.exe$/i, '');

    const newRule: AppRule = {
      id: `rule-${Date.now()}`,
      name: cleanWindowProcessName,
      processName: cleanWindowProcessName,
      path: win.path,
      proxyId: 'vless-frankfurt',
      enabled: true,
      proxyChildren: true,
      killSwitch: true,
      protocol: 'TCP_UDP',
      iconType: win.iconType,
      status: 'active',
      threads: 6,
      downSpeed: '↓ 340 КБ/с',
      upSpeed: '↑ 22 КБ/с',
      totalVolume: '88 МБ',
    };

    setRules([newRule, ...rules]);
    setIsRunningWindowsModalOpen(false);
    triggerToast(`Приложение ${cleanWindowProcessName} успешно добавлено из запущенных окон`);
  };

  // Edit rule submit
  const handleEditRuleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingRule) return;

    setRules((prev) => prev.map((r) => (r.id === editingRule.id ? editingRule : r)));
    setEditingRule(null);
    triggerToast(`Параметры правила обновлены`);
  };

  // Filter rules by search
  const filteredRules = useMemo(() => {
    if (!searchQuery.trim()) return rules;
    const q = searchQuery.toLowerCase().trim();
    return rules.filter(
      (r) =>
        r.processName.toLowerCase().includes(q) ||
        r.name.toLowerCase().includes(q) ||
        r.path.toLowerCase().includes(q)
    );
  }, [rules, searchQuery]);

  // Filter groups by search (matches if group name matches OR any member rule matches)
  const visibleGroups = useMemo(() => {
    if (!searchQuery.trim()) return groups;
    const q = searchQuery.toLowerCase().trim();
    return groups.filter((g) => {
      if (g.name.toLowerCase().includes(q)) return true;
      return rules.some(
        (r) =>
          r.groupId === g.id &&
          (r.processName.toLowerCase().includes(q) ||
            r.name.toLowerCase().includes(q) ||
            r.path.toLowerCase().includes(q))
      );
    });
  }, [groups, rules, searchQuery]);

  // Active vs Inactive groups
  const activeGroups = useMemo(() => visibleGroups.filter((g) => g.enabled), [visibleGroups]);
  const inactiveGroups = useMemo(() => visibleGroups.filter((g) => !g.enabled), [visibleGroups]);

  // Split all rules into active and inactive
  const activeRules = useMemo(() => filteredRules.filter((r) => r.enabled), [filteredRules]);
  const inactiveRules = useMemo(() => filteredRules.filter((r) => !r.enabled), [filteredRules]);

  // Standalone active and inactive rules (not belonging to any visible group)
  const standaloneActiveRules = useMemo(() => {
    return activeRules.filter((r) => !r.groupId || !groups.some((g) => g.id === r.groupId));
  }, [activeRules, groups]);

  const standaloneInactiveRules = useMemo(() => {
    return inactiveRules.filter((r) => !r.groupId || !groups.some((g) => g.id === r.groupId));
  }, [inactiveRules, groups]);

  // Aggregate telemetry
  const totalActiveThreads = useMemo(() => {
    if (!isEngineRunning) return 0;
    return rules.filter((r) => r.enabled && r.status === 'active').reduce((acc, curr) => acc + curr.threads, 0);
  }, [rules, isEngineRunning]);

  return (
    <div className="min-h-screen bg-[#0d0d0f] text-[#E4E4E7] flex flex-col justify-center items-center p-2 sm:p-4 select-none font-sans">
      {/* Windows 11 Desktop Application Shell */}
      <div
        className={`w-full ${
          windowMaximized ? 'max-w-none h-screen' : 'max-w-[1360px] h-[860px]'
        } bg-[#121214] border border-[#2A2A30] rounded-xl shadow-2xl flex flex-col overflow-hidden relative transition-all duration-200`}
      >
        {/* Native Windows Title Bar */}
        <div className="h-10 bg-[#121214] border-b border-[#2A2A30] flex items-center justify-between px-3 shrink-0">
          {/* Left Titlebar: Logo & Title */}
          <div className="flex items-center gap-2.5">
            <div className="w-5 h-5 rounded-md bg-[#F97316] flex items-center justify-center text-black shadow-[0_0_10px_rgba(249,115,22,0.4)]">
              {/* Ashgate custom gateway icon */}
              <svg viewBox="0 0 24 24" fill="none" className="w-3.5 h-3.5 stroke-black stroke-[2.5]" strokeLinecap="round" strokeLinejoin="round">
                <path d="M13 5l7 7-7 7M5 5l7 7-7 7" />
              </svg>
            </div>
            <span className="text-xs font-semibold tracking-wide text-zinc-300">Ashgate</span>
            <span className="text-[11px] text-zinc-500 font-mono">v1.4.2 · Windows Desktop</span>
          </div>

          {/* Right Titlebar: Window Controls */}
          <div className="flex items-center space-x-1 -mr-1">
            <button
              onClick={() => triggerToast('Окно свернуто в системный трей Windows')}
              className="w-10 h-8 flex items-center justify-center text-zinc-400 hover:text-white hover:bg-[#1E1E22] rounded transition-colors"
              title="Свернуть"
            >
              <div className="w-2.5 h-[1.5px] bg-current" />
            </button>
            <button
              onClick={() => setWindowMaximized(!windowMaximized)}
              className="w-10 h-8 flex items-center justify-center text-zinc-400 hover:text-white hover:bg-[#1E1E22] rounded transition-colors"
              title={windowMaximized ? 'Восстановить' : 'Развернуть'}
            >
              <div className="w-2.5 h-2.5 border-[1.5px] border-current rounded-[1px]" />
            </button>
            <button
              onClick={() => triggerToast('Приложение Ashgate продолжает работу в фоновом режиме')}
              className="w-10 h-8 flex items-center justify-center text-zinc-400 hover:text-white hover:bg-[#E81123] rounded transition-colors"
              title="Закрыть"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Main Application Body (Sidebar + Content Workspace) */}
        <div className="flex-1 flex overflow-hidden">
          {/* Left Sidebar (Fixed 236px, strictly matching screenshot) */}
          <aside className="w-[236px] bg-[#121214] border-r border-[#2A2A30] flex flex-col justify-between p-3 shrink-0">
            {/* Top Brand & Nav Section */}
            <div className="space-y-6">
              {/* App Brand Header */}
              <div className="flex items-center gap-2.5 px-2 pt-1">
                <div className="w-6 h-6 rounded-lg bg-[#F97316] flex items-center justify-center text-black font-bold shadow-md shadow-orange-500/20">
                  <svg viewBox="0 0 24 24" fill="none" className="w-4 h-4 stroke-black stroke-[2.5]" strokeLinecap="round" strokeLinejoin="round">
                    <circle cx="12" cy="12" r="10" />
                    <polyline points="12 8 16 12 12 16" />
                    <line x1="8" y1="12" x2="16" y2="12" />
                  </svg>
                </div>
                <div className="flex flex-col">
                  <span className="text-[15px] font-bold text-white tracking-tight">Ashgate</span>
                </div>
              </div>

              {/* Navigation Menu */}
              <nav className="space-y-1">
                {/* 1. Главная */}
                <button
                  onClick={() => setActiveTab('home')}
                  className={`w-full flex items-center gap-3 px-3 py-2 rounded-lg text-sm transition-all text-left ${
                    activeTab === 'home'
                      ? 'bg-[#1E1E22] text-white font-medium'
                      : 'text-zinc-400 hover:text-zinc-200 hover:bg-[#18181B]'
                  }`}
                >
                  <Home className="w-4 h-4 text-zinc-400" />
                  <span>Главная</span>
                </button>

                {/* 2. Прокси (1) */}
                <button
                  onClick={() => setActiveTab('proxies')}
                  className={`w-full flex items-center justify-between px-3 py-2 rounded-lg text-sm transition-all text-left ${
                    activeTab === 'proxies'
                      ? 'bg-[#1E1E22] text-white font-medium'
                      : 'text-zinc-400 hover:text-zinc-200 hover:bg-[#18181B]'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <Server className="w-4 h-4 text-zinc-400" />
                    <span>Прокси</span>
                  </div>
                  <span className="text-xs text-zinc-500 font-mono">1</span>
                </button>

                {/* 3. Приложения (5) - ACTIVE WITH ORANGE INDICATOR */}
                <button
                  onClick={() => setActiveTab('apps')}
                  className={`w-full relative flex items-center justify-between px-3 py-2 rounded-lg text-sm transition-all text-left ${
                    activeTab === 'apps'
                      ? 'bg-[#1E1E22] text-white font-semibold shadow-sm'
                      : 'text-zinc-400 hover:text-zinc-200 hover:bg-[#18181B]'
                  }`}
                >
                  {/* Left Orange Indicator Strip matching screenshot */}
                  {activeTab === 'apps' && (
                    <div className="absolute left-0 top-1.5 bottom-1.5 w-[3px] bg-[#F97316] rounded-r-full shadow-[0_0_8px_rgba(249,115,22,0.8)]" />
                  )}

                  <div className="flex items-center gap-3 pl-1">
                    <Layers className="w-4 h-4 text-[#F97316]" />
                    <span className="text-zinc-100">Приложения</span>
                  </div>
                  <span className="text-xs font-mono px-1.5 py-0.5 rounded text-zinc-400 bg-[#25252B]">
                    {rules.length}
                  </span>
                </button>

                {/* 4. Подключения */}
                <button
                  onClick={() => setActiveTab('connections')}
                  className={`w-full flex items-center gap-3 px-3 py-2 rounded-lg text-sm transition-all text-left ${
                    activeTab === 'connections'
                      ? 'bg-[#1E1E22] text-white font-medium'
                      : 'text-zinc-400 hover:text-zinc-200 hover:bg-[#18181B]'
                  }`}
                >
                  <Activity className="w-4 h-4 text-zinc-400" />
                  <span>Подключения</span>
                </button>

                {/* 5. Настройки */}
                <button
                  onClick={() => setActiveTab('settings')}
                  className={`w-full flex items-center gap-3 px-3 py-2 rounded-lg text-sm transition-all text-left ${
                    activeTab === 'settings'
                      ? 'bg-[#1E1E22] text-white font-medium'
                      : 'text-zinc-400 hover:text-zinc-200 hover:bg-[#18181B]'
                  }`}
                >
                  <Sliders className="w-4 h-4 text-zinc-400" />
                  <span>Настройки</span>
                </button>
              </nav>
            </div>

            {/* Bottom Sidebar Status Card (Minimalist & Clean) */}
            <div className="relative overflow-hidden rounded-xl border border-[#272730] bg-[#18181C] p-3.5 space-y-3 shadow-md transition-all">
              {/* Subtle top edge glow */}
              <div
                className={`absolute top-0 left-0 right-0 h-[1.5px] transition-all duration-500 ${
                  isEngineRunning
                    ? 'bg-gradient-to-r from-transparent via-emerald-500/50 to-transparent'
                    : 'bg-gradient-to-r from-transparent via-zinc-700/30 to-transparent'
                }`}
              />

              {/* Status Header: Beacon + Title */}
              <div className="flex items-center gap-2.5">
                <div className="relative flex items-center justify-center w-2.5 h-2.5 shrink-0">
                  {isEngineRunning && (
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-40" />
                  )}
                  <span
                    className={`relative inline-flex rounded-full w-2.5 h-2.5 transition-all duration-300 ${
                      isEngineRunning
                        ? 'bg-emerald-400 shadow-[0_0_8px_rgba(52,211,153,0.8)]'
                        : 'bg-zinc-600'
                    }`}
                  />
                </div>
                <span className="text-xs font-semibold text-zinc-200 tracking-tight">
                  {isEngineRunning ? 'Работает' : 'Остановлен'}
                </span>
              </div>

              {/* Power Switch Action Button (Enlarged) */}
              <button
                onClick={() => {
                  const newState = !isEngineRunning;
                  setIsEngineRunning(newState);
                  triggerToast(newState ? 'Ядро Ashgate запущено' : 'Ядро Ashgate остановлено');
                }}
                className={`relative group w-full py-2.5 px-4 rounded-xl text-xs font-semibold flex items-center justify-center gap-2 transition-all cursor-pointer overflow-hidden ${
                  isEngineRunning
                    ? 'bg-[#222228] hover:bg-[#282830] active:scale-[0.98] text-zinc-200 hover:text-white border border-[#2F2F39] hover:border-red-500/40 shadow-sm'
                    : 'bg-gradient-to-r from-[#F97316] to-[#EA580C] hover:from-[#FB923C] hover:to-[#F97316] active:scale-[0.98] text-black shadow-md shadow-orange-500/25 border border-orange-400/40'
                }`}
              >
                {/* Subtle hover gradient shine when running */}
                {isEngineRunning && (
                  <div className="absolute inset-0 bg-gradient-to-r from-red-500/0 via-red-500/10 to-red-500/0 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none" />
                )}
                <Power
                  className={`w-4 h-4 transition-colors shrink-0 ${
                    isEngineRunning
                      ? 'text-zinc-400 group-hover:text-red-400'
                      : 'text-black stroke-[2.5]'
                  }`}
                />
                <span className="relative z-10">
                  {isEngineRunning ? 'Стоп' : 'Запустить'}
                </span>
              </button>
            </div>
          </aside>

          {/* Main Content Workspace (Background #161618) */}
          <main className="flex-1 bg-[#161618] flex flex-col overflow-hidden">
            {/* Header of «Приложения» Tab */}
            <div className="px-6 pt-6 pb-4 border-b border-[#2A2A30] shrink-0 bg-[#161618]">
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                {/* Left Header Description */}
                <div>
                  <h1 className="text-2xl font-bold text-white tracking-tight">Приложения</h1>
                  <p className="text-xs text-zinc-400 mt-1 max-w-xl leading-relaxed">
                    Маршрутизация трафика выбранных процессов. Остальные программы работают напрямую.
                  </p>
                </div>

                {/* Right Header Action Toolbar */}
                <div className="flex flex-wrap items-center gap-2.5 shrink-0">
                  {/* Search bar */}
                  <div className="relative">
                    <Search className="w-3.5 h-3.5 text-zinc-500 absolute left-3 top-1/2 -translate-y-1/2" />
                    <input
                      type="text"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      placeholder="Поиск по процессам..."
                      className="w-36 md:w-44 lg:w-52 bg-[#1E1E22] border border-[#2A2A30] focus:border-[#F97316] rounded-lg pl-8 pr-7 py-1.5 text-xs text-zinc-200 placeholder-zinc-500 outline-none transition-all"
                    />
                    {searchQuery && (
                      <button
                        onClick={() => setSearchQuery('')}
                        className="absolute right-2 top-1/2 -translate-y-1/2 text-zinc-500 hover:text-zinc-300"
                      >
                        <X className="w-3 h-3" />
                      </button>
                    )}
                  </div>

                  {/* Download Bundle for Claude Code (Prominent Accent Style) */}
                  <a
                    href="/ashgate-ui-bundle.zip"
                    download="ashgate-ui-bundle.zip"
                    className="flex items-center gap-1.5 px-3 py-1.5 bg-[#F97316]/15 hover:bg-[#F97316]/25 text-orange-200 hover:text-white border border-[#F97316]/40 rounded-lg text-xs font-semibold transition-all shadow-sm shadow-orange-500/10 cursor-pointer"
                    title="Скачать ZIP-архив с кодом и инструкцией для Claude Code"
                  >
                    <Download className="w-3.5 h-3.5 text-[#F97316]" />
                    <span>Скачать ZIP</span>
                  </a>

                  {/* Secondary Action: Из запущенных окон */}
                  <button
                    onClick={() => setIsRunningWindowsModalOpen(true)}
                    className="flex items-center gap-1.5 px-3 py-1.5 bg-[#1E1E22] hover:bg-[#26262C] text-zinc-300 hover:text-white border border-[#2A2A30] rounded-lg text-xs font-medium transition-colors cursor-pointer"
                  >
                    <AppWindow className="w-3.5 h-3.5 text-zinc-400" />
                    <span className="hidden sm:inline">Из окон</span>
                  </button>

                  {/* Primary Accent Action: + Добавить приложение */}
                  <button
                    onClick={() => setIsAddModalOpen(true)}
                    className="flex items-center gap-1.5 px-3.5 py-1.5 bg-[#F97316] hover:bg-[#EA580C] text-black font-semibold rounded-lg text-xs shadow-md shadow-orange-500/20 transition-all hover:scale-[1.01] active:scale-[0.98] cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5 stroke-[2.5]" />
                    <span>Добавить</span>
                  </button>
                </div>
              </div>

              {/* Informational Notification Banner if Spotify has a triggered Kill Switch */}
              {rules.some((r) => r.status === 'blocked' && r.enabled) && (
                <div className="mt-3.5 bg-red-500/10 border border-red-500/25 rounded-lg p-2.5 flex items-center justify-between text-xs">
                  <div className="flex items-center gap-2 text-red-300">
                    <AlertTriangle className="w-4 h-4 text-red-400 shrink-0" />
                    <span>
                      <strong className="font-semibold text-red-200">Внимание:</strong> SOCKS5 шлюз недоступен. Трафик Spotify заблокирован Kill Switch для предотвращения утечки IP.
                    </span>
                  </div>
                  <button
                    onClick={handleFixSpotify}
                    className="px-2.5 py-1 bg-red-500/20 hover:bg-red-500/30 text-red-200 border border-red-500/30 rounded text-[11px] font-medium transition-colors shrink-0 cursor-pointer ml-3"
                  >
                    Переключить на VLESS
                  </button>
                </div>
              )}
            </div>

            {/* Content Scrollable List Area */}
            <div className="flex-1 overflow-y-auto px-6 py-4 space-y-4">
              {/* Prominent Claude Code Export Banner */}
              <div className="bg-gradient-to-r from-[#1E1E26] via-[#241F28] to-[#1C1C22] border border-[#F97316]/50 rounded-xl p-3.5 flex flex-wrap items-center justify-between gap-3 shadow-lg shadow-orange-500/10">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-lg bg-[#F97316]/20 border border-[#F97316]/40 flex items-center justify-center shrink-0">
                    <Download className="w-5 h-5 text-[#F97316]" />
                  </div>
                  <div>
                    <div className="text-xs font-bold text-white flex items-center gap-2">
                      <span>Архив для Claude Code готов к загрузке</span>
                      <span className="text-[10px] font-mono text-[#F97316] bg-[#F97316]/10 px-1.5 py-0.5 rounded border border-[#F97316]/20">
                        ashgate-ui-bundle.zip
                      </span>
                    </div>
                    <p className="text-[11px] text-zinc-400 mt-0.5">
                      Внутри: исходный код <code className="text-zinc-300 font-mono">src/</code>, бандл <code className="text-zinc-300 font-mono">dist/</code> и подробное ТЗ в <code className="text-orange-300 font-mono">CLAUDE.md</code>
                    </p>
                  </div>
                </div>
                <a
                  href="/ashgate-ui-bundle.zip"
                  download="ashgate-ui-bundle.zip"
                  className="flex items-center gap-2 px-4 py-2 bg-[#F97316] hover:bg-[#EA580C] text-black font-bold rounded-lg text-xs shadow-md shadow-orange-500/25 transition-all hover:scale-[1.02] active:scale-[0.98] cursor-pointer"
                >
                  <Download className="w-4 h-4 stroke-[2.5]" />
                  <span>Скачать ZIP-архив</span>
                </a>
              </div>
              {/* Batch Selection & Grouping Action Banner (Appears only when rules are checked) */}
              {selectedRuleIds.length > 0 && (
                <div className="bg-[#1C1C22] border border-[#F97316]/40 rounded-xl p-3 flex flex-wrap items-center justify-between gap-3 shadow-lg shadow-orange-500/5 animate-in fade-in slide-in-from-top-1">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-lg bg-[#F97316]/20 border border-[#F97316]/40 flex items-center justify-center text-[#F97316] shrink-0">
                      <FolderPlus className="w-4 h-4" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold text-white">
                          Выбрано правил: {selectedRuleIds.length}
                        </span>
                        <span className="text-zinc-600">·</span>
                        <button
                          type="button"
                          onClick={handleSelectAllActive}
                          className="text-xs text-[#F97316] hover:underline cursor-pointer"
                        >
                          Выбрать все активные ({activeRules.length})
                        </button>
                        {selectedRuleIds.length > 0 && (
                          <>
                            <span className="text-zinc-600">·</span>
                            <button
                              type="button"
                              onClick={() => setSelectedRuleIds([])}
                              className="text-xs text-zinc-400 hover:text-zinc-200 cursor-pointer"
                            >
                              Снять выбор
                            </button>
                          </>
                        )}
                      </div>
                      <p className="text-[11px] text-zinc-400 mt-0.5">
                        Отметьте галочками нужные приложения, чтобы сгруппировать их в единую папку с общим тумблером и прокси
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => {
                        setIsSelectionMode(false);
                        setSelectedRuleIds([]);
                      }}
                      className="px-3 py-1.5 rounded-lg bg-[#18181C] hover:bg-[#222228] border border-[#2A2A30] text-zinc-300 text-xs transition-colors cursor-pointer"
                    >
                      Отмена
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        if (selectedRuleIds.length === 0) {
                          triggerToast('Выберите хотя бы одно приложение галочкой');
                          return;
                        }
                        setNewGroupName('');
                        setIsCreateGroupModalOpen(true);
                      }}
                      disabled={selectedRuleIds.length === 0}
                      className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                        selectedRuleIds.length > 0
                          ? 'bg-[#F97316] hover:bg-[#EA580C] text-black shadow-md shadow-orange-500/20 active:scale-[0.98]'
                          : 'bg-[#222226] text-zinc-600 border border-[#2A2A30] cursor-not-allowed'
                      }`}
                    >
                      <FolderPlus className="w-3.5 h-3.5 stroke-[2.5]" />
                      <span>Сгруппировать ({selectedRuleIds.length})</span>
                    </button>
                  </div>
                </div>
              )}

              {/* Section 1: Активные правила (включая активные группы) */}
              <div className="space-y-2.5">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-semibold text-zinc-300 uppercase tracking-wider">
                      Активные правила
                    </span>
                    <span className="text-[11px] font-mono font-medium px-2 py-0.5 rounded-full bg-[#1E1E22] border border-[#2A2A30] text-[#F97316]">
                      {activeRules.length}
                    </span>
                    {activeGroups.length > 0 && (
                      <span className="text-[11px] text-zinc-500 font-mono">
                        ({activeGroups.length} {activeGroups.length === 1 ? 'группа' : activeGroups.length < 5 ? 'группы' : 'групп'})
                      </span>
                    )}
                  </div>
                  <span className="text-[11px] text-zinc-500">
                    Проверяются сверху вниз — срабатывает первое совпадение
                  </span>
                </div>

                {activeRules.length === 0 && activeGroups.length === 0 ? (
                  <div className="bg-[#1E1E22]/50 border border-dashed border-[#2A2A30] rounded-xl p-8 text-center text-xs text-zinc-500">
                    Нет активных правил. Включите тумблер ниже или добавьте новое приложение.
                  </div>
                ) : (
                  <div className="space-y-2">
                    {/* 1. Active Groups */}
                    {activeGroups.map((group) => {
                      const memberRules = rules.filter((r) => r.groupId === group.id);
                      return (
                        <GroupRowItem
                          key={group.id}
                          group={group}
                          members={memberRules}
                          onToggleGroup={handleToggleGroup}
                          onToggleCollapse={handleToggleGroupCollapse}
                          onUngroup={handleUngroup}
                          onAssignGroupProxy={handleAssignGroupProxy}
                          onDeleteGroup={handleDeleteGroup}
                          isContextMenuOpen={openGroupContextMenuId === group.id}
                          isProxySelectorOpen={openGroupProxySelectorId === group.id}
                          onOpenContextMenu={(id) => setOpenGroupContextMenuId(id)}
                          onOpenProxySelector={(id) => setOpenGroupProxySelectorId(id)}
                          onToggleRule={handleToggleRule}
                          onOpenRuleProxySelector={(id) => setOpenProxySelectorRuleId(id)}
                          onOpenRuleContextMenu={(id) => setOpenContextMenuRuleId(id)}
                          openContextMenuRuleId={openContextMenuRuleId}
                          openProxySelectorRuleId={openProxySelectorRuleId}
                          onAssignRuleProxy={handleAssignProxy}
                          onUpdateRuleSetting={handleUpdateRuleSetting}
                          onDeleteRule={handleDeleteRule}
                          onEditRule={(r) => setEditingRule(r)}
                          onRemoveRuleFromGroup={handleRemoveRuleFromGroup}
                          isSelectionMode={isSelectionMode}
                          selectedRuleIds={selectedRuleIds}
                          onSelectRule={handleToggleRuleSelection}
                        />
                      );
                    })}

                    {/* 2. Standalone Active Rules */}
                    {standaloneActiveRules.map((rule) => (
                      <RuleRowItem
                        key={rule.id}
                        rule={rule}
                        onToggle={handleToggleRule}
                        onOpenProxySelector={(id) => setOpenProxySelectorRuleId(id)}
                        onOpenContextMenu={(id) => setOpenContextMenuRuleId(id)}
                        isContextMenuOpen={openContextMenuRuleId === rule.id}
                        isProxySelectorOpen={openProxySelectorRuleId === rule.id}
                        onAssignProxy={handleAssignProxy}
                        onUpdateSetting={handleUpdateRuleSetting}
                        onDelete={handleDeleteRule}
                        onEdit={(r) => setEditingRule(r)}
                        isSelectionMode={isSelectionMode}
                        isSelected={selectedRuleIds.includes(rule.id)}
                        onSelect={handleToggleRuleSelection}
                      />
                    ))}
                  </div>
                )}
              </div>

              {/* Section 2: Отключенные и неактивные (включая отключенные группы) */}
              <div className="space-y-2.5 pt-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-semibold text-zinc-400 uppercase tracking-wider">
                      Отключенные и неактивные
                    </span>
                    <span className="text-[11px] font-mono font-medium px-2 py-0.5 rounded-full bg-[#1E1E22] border border-[#2A2A30] text-zinc-500">
                      {inactiveRules.length}
                    </span>
                  </div>
                  <span className="text-[11px] text-zinc-600">
                    Трафик направляется напрямую в обход прокси
                  </span>
                </div>

                {inactiveRules.length === 0 && inactiveGroups.length === 0 ? (
                  <div className="bg-[#1E1E22]/30 border border-[#2A2A30]/50 rounded-xl p-4 text-center text-xs text-zinc-600">
                    Все правила в данный момент активны.
                  </div>
                ) : (
                  <div className="space-y-2 opacity-75 hover:opacity-100 transition-opacity duration-200">
                    {/* Inactive Groups */}
                    {inactiveGroups.map((group) => {
                      const memberRules = rules.filter((r) => r.groupId === group.id);
                      return (
                        <GroupRowItem
                          key={group.id}
                          group={group}
                          members={memberRules}
                          onToggleGroup={handleToggleGroup}
                          onToggleCollapse={handleToggleGroupCollapse}
                          onUngroup={handleUngroup}
                          onAssignGroupProxy={handleAssignGroupProxy}
                          onDeleteGroup={handleDeleteGroup}
                          isContextMenuOpen={openGroupContextMenuId === group.id}
                          isProxySelectorOpen={openGroupProxySelectorId === group.id}
                          onOpenContextMenu={(id) => setOpenGroupContextMenuId(id)}
                          onOpenProxySelector={(id) => setOpenGroupProxySelectorId(id)}
                          onToggleRule={handleToggleRule}
                          onOpenRuleProxySelector={(id) => setOpenProxySelectorRuleId(id)}
                          onOpenRuleContextMenu={(id) => setOpenContextMenuRuleId(id)}
                          openContextMenuRuleId={openContextMenuRuleId}
                          openProxySelectorRuleId={openProxySelectorRuleId}
                          onAssignRuleProxy={handleAssignProxy}
                          onUpdateRuleSetting={handleUpdateRuleSetting}
                          onDeleteRule={handleDeleteRule}
                          onEditRule={(r) => setEditingRule(r)}
                          onRemoveRuleFromGroup={handleRemoveRuleFromGroup}
                          isSelectionMode={isSelectionMode}
                          selectedRuleIds={selectedRuleIds}
                          onSelectRule={handleToggleRuleSelection}
                        />
                      );
                    })}

                    {/* Standalone Inactive Rules */}
                    {standaloneInactiveRules.map((rule) => (
                      <RuleRowItem
                        key={rule.id}
                        rule={rule}
                        onToggle={handleToggleRule}
                        onOpenProxySelector={(id) => setOpenProxySelectorRuleId(id)}
                        onOpenContextMenu={(id) => setOpenContextMenuRuleId(id)}
                        isContextMenuOpen={openContextMenuRuleId === rule.id}
                        isProxySelectorOpen={openProxySelectorRuleId === rule.id}
                        onAssignProxy={handleAssignProxy}
                        onUpdateSetting={handleUpdateRuleSetting}
                        onDelete={handleDeleteRule}
                        onEdit={(r) => setEditingRule(r)}
                        isSelectionMode={isSelectionMode}
                        isSelected={selectedRuleIds.includes(rule.id)}
                        onSelect={handleToggleRuleSelection}
                      />
                    ))}
                  </div>
                )}
              </div>

              {/* Bottom Tip matching the screenshot note */}
              <div className="pt-4 pb-2 border-t border-[#2A2A30]/50 text-xs text-zinc-500 flex items-start gap-2">
                <Info className="w-4 h-4 text-zinc-600 shrink-0 mt-0.5" />
                <span>
                  Для системных служб Windows (svchost.exe, DNS) используйте раздел «Настройки → Системный резолвер». 
                  Правила применяются к исходящим TCP и UDP пакетам автоматически через системный драйвер сокетов.
                </span>
              </div>
            </div>
          </main>
        </div>
      </div>

      {/* MODAL 1: + Добавить приложение */}
      {isAddModalOpen && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="w-full max-w-lg bg-[#18181C] border border-[#2A2A30] rounded-xl shadow-2xl p-5 space-y-4 max-h-[92vh] overflow-y-auto">
            {/* Header */}
            <div className="flex items-center justify-between border-b border-[#2A2A30] pb-3">
              <div className="flex items-center gap-2.5">
                <div className="w-7 h-7 rounded-lg bg-[#F97316]/20 border border-[#F97316]/40 flex items-center justify-center text-[#F97316]">
                  <Plus className="w-4 h-4 stroke-[2.5]" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-white">Добавить правило приложения</h3>
                  <p className="text-[11px] text-zinc-400">Настройка маршрутизации трафика процесса</p>
                </div>
              </div>
              <button
                onClick={() => setIsAddModalOpen(false)}
                className="text-zinc-500 hover:text-zinc-300 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleAddRuleSubmit} className="space-y-4 text-xs">
              {/* 1. Поиск приложения по названию с автоматическим подтягиванием .exe пути */}
              <div className="space-y-1.5">
                <label className="block text-zinc-300 font-medium">
                  Поиск приложения по названию:
                </label>
                <div className="relative">
                  <Search className="w-4 h-4 text-zinc-500 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    required
                    placeholder="Например: Telegram, Cursor, Discord, Figma, Steam..."
                    value={newProcessName}
                    onChange={(e) => handleProcessNameInputChange(e.target.value)}
                    className="w-full bg-[#121214] border border-[#2A2A30] focus:border-[#F97316] rounded-lg pl-9 pr-8 py-2 text-zinc-100 placeholder-zinc-500 outline-none text-xs transition-colors"
                  />
                  {newProcessName && (
                    <button
                      type="button"
                      onClick={() => handleProcessNameInputChange('')}
                      className="absolute right-2.5 top-1/2 -translate-y-1/2 text-zinc-500 hover:text-zinc-300"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>

                {/* Автоматически сгенерированный / подтянутый путь до .exe */}
                <div className="bg-[#121214] border border-[#25252B] rounded-lg px-2.5 py-1.5 flex items-center justify-between gap-2">
                  <div className="flex items-center gap-1.5 min-w-0 flex-1">
                    <span className="text-[10px] text-zinc-500 shrink-0 font-medium">Путь (.exe):</span>
                    <input
                      type="text"
                      value={newPath}
                      onChange={(e) => setNewPath(e.target.value)}
                      placeholder="Путь подтягивается автоматически при вводе..."
                      className="bg-transparent text-[11px] text-[#F97316] font-mono outline-none w-full truncate placeholder-zinc-600"
                    />
                  </div>
                  <span className="text-[9px] uppercase tracking-wider text-emerald-400 font-mono bg-emerald-500/10 px-1.5 py-0.5 rounded shrink-0 border border-emerald-500/20">
                    Автокод
                  </span>
                </div>
              </div>

              {/* Красивый разделитель "или" */}
              <div className="relative flex items-center justify-center my-3 py-0.5">
                <div className="absolute inset-0 flex items-center">
                  <div className="w-full border-t border-[#2A2A30]" />
                </div>
                <div className="relative px-3 bg-[#18181C] text-[10px] text-zinc-400 uppercase tracking-widest font-semibold border border-[#2A2A30] rounded-full py-0.5">
                  или
                </div>
              </div>

              {/* Текущие активные предложения (запущенные процессы) */}
              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <label className="text-zinc-300 font-medium">
                    Текущие активные приложения:
                  </label>
                  <span className="text-[11px] text-zinc-500">
                    Кликните для быстрого выбора
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-1.5 max-h-[140px] overflow-y-auto pr-0.5">
                  {RUNNING_WINDOWS_SAMPLE.map((win) => {
                    const isSelected = selectedRunningAppPid === win.pid || (newProcessName.trim() && newProcessName.toLowerCase() === win.processName.toLowerCase());
                    return (
                      <div
                        key={win.pid}
                        onClick={() => handleSelectRunningApp(win)}
                        className={`p-2 rounded-lg border flex items-center gap-2.5 cursor-pointer transition-all ${
                          isSelected
                            ? 'bg-[#1E1E22] border-[#F97316] shadow-sm shadow-orange-500/20'
                            : 'bg-[#121214] border-[#2A2A30] hover:bg-[#1A1A1E] hover:border-zinc-500/50'
                        }`}
                      >
                        <div className="w-6 h-6 rounded-md bg-[#25252B] flex items-center justify-center shrink-0">
                          <AppIcon type={win.iconType} />
                        </div>
                        <div className="min-w-0 flex-1">
                          <div className="flex items-center justify-between">
                            <span className="font-semibold text-white truncate text-[11px]">
                              {win.processName}
                            </span>
                            {isSelected && <Check className="w-3 h-3 text-[#F97316] shrink-0 ml-1" />}
                          </div>
                          <div className="text-[10px] text-zinc-500 truncate mt-0.5 font-mono">
                            PID: {win.pid}
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* 3. Меню "Маршрутизировать через" (в точности как бейдж-селектор на основной вкладке) */}
              <div>
                <label className="block text-zinc-300 mb-1.5 font-medium">
                  Маршрутизировать через:
                </label>
                <div className="relative add-proxy-selector-container">
                  <button
                    type="button"
                    onClick={() => setIsAddModalProxyDropdownOpen(!isAddModalProxyDropdownOpen)}
                    className="w-full flex items-center justify-between px-3 py-2 bg-[#121214] hover:bg-[#1A1A1E] border border-[#2A2A30] rounded-lg text-xs font-mono transition-colors cursor-pointer"
                  >
                    <div className="flex items-center gap-2 min-w-0">
                      {selectedModalProxy.type === 'VLESS' ? (
                        <Zap className="w-4 h-4 text-[#F97316] shrink-0" />
                      ) : selectedModalProxy.type === 'SOCKS5' ? (
                        <Shield className="w-4 h-4 text-sky-400 shrink-0" />
                      ) : (
                        <Globe className="w-4 h-4 text-zinc-400 shrink-0" />
                      )}
                      <span className="font-semibold text-zinc-100">{selectedModalProxy.name}</span>
                      <span className="text-zinc-600">·</span>
                      <span className="text-zinc-400 truncate">{selectedModalProxy.endpoint}</span>
                    </div>

                    <div className="flex items-center gap-2 shrink-0 ml-2">
                      {selectedModalProxy.status === 'online' ? (
                        <span className="text-[10px] text-emerald-400 font-mono">{selectedModalProxy.pingMs}ms</span>
                      ) : (
                        <span className="text-[10px] text-red-400 font-mono">Offline</span>
                      )}
                      <ChevronDown className="w-3.5 h-3.5 text-zinc-500" />
                    </div>
                  </button>

                  {/* Popover Dropdown */}
                  {isAddModalProxyDropdownOpen && (
                    <div className="absolute left-0 right-0 top-full mt-1.5 bg-[#1C1C20] border border-[#2A2A30] rounded-xl shadow-2xl p-1.5 z-50 text-xs animate-in fade-in zoom-in-95 space-y-0.5">
                      <div className="px-2.5 py-1 text-[10px] font-semibold text-zinc-400 uppercase tracking-wider">
                        Выберите шлюз прокси
                      </div>
                      {AVAILABLE_PROXIES.map((p) => (
                        <button
                          key={p.id}
                          type="button"
                          onClick={() => {
                            setNewProxyId(p.id);
                            setIsAddModalProxyDropdownOpen(false);
                          }}
                          className={`w-full flex items-center justify-between px-2.5 py-2 rounded-lg text-left transition-colors cursor-pointer ${
                            p.id === newProxyId
                              ? 'bg-[#F97316]/15 text-white font-medium border border-[#F97316]/30'
                              : 'text-zinc-300 hover:bg-[#25252B]'
                          }`}
                        >
                          <div className="flex items-center gap-2 min-w-0">
                            {p.type === 'VLESS' ? (
                              <Zap className="w-3.5 h-3.5 text-[#F97316] shrink-0" />
                            ) : p.type === 'SOCKS5' ? (
                              <Shield className="w-3.5 h-3.5 text-sky-400 shrink-0" />
                            ) : (
                              <Globe className="w-3.5 h-3.5 text-zinc-400 shrink-0" />
                            )}
                            <div className="truncate">
                              <div className="font-medium truncate">{p.name}</div>
                              <div className="text-[10px] text-zinc-500 font-mono">{p.endpoint}</div>
                            </div>
                          </div>

                          <div className="flex items-center gap-1.5 shrink-0 ml-2">
                            {p.status === 'online' ? (
                              <span className="text-[10px] text-emerald-400 font-mono">{p.pingMs}ms</span>
                            ) : (
                              <span className="text-[10px] text-red-400 font-mono">Offline</span>
                            )}
                            {p.id === newProxyId && <Check className="w-3.5 h-3.5 text-[#F97316]" />}
                          </div>
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              </div>

              {/* 4. Симпатичные галочки в гармонии с основным дизайном */}
              <div className="space-y-2 pt-2 border-t border-[#2A2A30]">
                {/* Checkbox 1: Дочерние процессы */}
                <div
                  onClick={() => setNewProxyChildren(!newProxyChildren)}
                  className={`flex items-start gap-3 p-2.5 rounded-lg border transition-all cursor-pointer ${
                    newProxyChildren
                      ? 'bg-[#1E1E22] border-[#F97316]/40 shadow-sm'
                      : 'bg-[#141416] border-[#2A2A30] hover:border-[#383842]'
                  }`}
                >
                  <div
                    className={`w-4 h-4 rounded mt-0.5 flex items-center justify-center transition-all shrink-0 ${
                      newProxyChildren
                        ? 'bg-[#F97316] text-black shadow-sm shadow-orange-500/30'
                        : 'border border-[#3A3A44] bg-[#18181C] hover:border-zinc-500'
                    }`}
                  >
                    {newProxyChildren && <Check className="w-3 h-3 stroke-[3]" />}
                  </div>
                  <div className="flex flex-col select-none">
                    <span className={`text-xs font-medium transition-colors ${newProxyChildren ? 'text-zinc-100' : 'text-zinc-300'}`}>
                      Проксировать дочерние процессы (child processes)
                    </span>
                    <span className="text-[11px] text-zinc-500 mt-0.5">
                      Автоматически маршрутизировать сетевой трафик порожденных подпроцессов
                    </span>
                  </div>
                </div>

                {/* Checkbox 2: Kill Switch */}
                <div
                  onClick={() => setNewKillSwitch(!newKillSwitch)}
                  className={`flex items-start gap-3 p-2.5 rounded-lg border transition-all cursor-pointer ${
                    newKillSwitch
                      ? 'bg-[#1E1E22] border-[#F97316]/40 shadow-sm'
                      : 'bg-[#141416] border-[#2A2A30] hover:border-[#383842]'
                  }`}
                >
                  <div
                    className={`w-4 h-4 rounded mt-0.5 flex items-center justify-center transition-all shrink-0 ${
                      newKillSwitch
                        ? 'bg-[#F97316] text-black shadow-sm shadow-orange-500/30'
                        : 'border border-[#3A3A44] bg-[#18181C] hover:border-zinc-500'
                    }`}
                  >
                    {newKillSwitch && <Check className="w-3 h-3 stroke-[3]" />}
                  </div>
                  <div className="flex flex-col select-none">
                    <span className={`text-xs font-medium transition-colors ${newKillSwitch ? 'text-zinc-100' : 'text-zinc-300'}`}>
                      Включить Kill Switch (защита от утечки IP)
                    </span>
                    <span className="text-[11px] text-zinc-500 mt-0.5">
                      Мгновенно изолировать сетевой трафик приложения при сбое или разрыве соединения с прокси
                    </span>
                  </div>
                </div>
              </div>

              {/* Protocol selector */}
              <div>
                <label className="block text-zinc-400 mb-1 font-medium">Протокол:</label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setNewProtocol('TCP_UDP')}
                    className={`py-1.5 px-3 rounded-lg border text-center transition-colors cursor-pointer ${
                      newProtocol === 'TCP_UDP'
                        ? 'bg-[#1E1E22] border-[#F97316] text-[#F97316] font-semibold'
                        : 'bg-[#121214] border-[#2A2A30] text-zinc-400'
                    }`}
                  >
                    TCP + UDP
                  </button>
                  <button
                    type="button"
                    onClick={() => setNewProtocol('TCP_ONLY')}
                    className={`py-1.5 px-3 rounded-lg border text-center transition-colors cursor-pointer ${
                      newProtocol === 'TCP_ONLY'
                        ? 'bg-[#1E1E22] border-[#F97316] text-[#F97316] font-semibold'
                        : 'bg-[#121214] border-[#2A2A30] text-zinc-400'
                    }`}
                  >
                    Только TCP
                  </button>
                </div>
              </div>

              {/* Buttons */}
              <div className="flex items-center justify-end gap-2 pt-3 border-t border-[#2A2A30]">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="px-3.5 py-1.5 bg-[#1E1E22] hover:bg-[#25252B] text-zinc-400 hover:text-white rounded-lg transition-colors cursor-pointer"
                >
                  Отмена
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 bg-[#F97316] hover:bg-[#EA580C] text-black font-semibold rounded-lg shadow-sm transition-colors cursor-pointer"
                >
                  Добавить в список
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 2: Из запущенных окон */}
      {isRunningWindowsModalOpen && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="w-full max-w-lg bg-[#18181C] border border-[#2A2A30] rounded-xl shadow-2xl p-5 space-y-4">
            <div className="flex items-center justify-between border-b border-[#2A2A30] pb-3">
              <div className="flex items-center gap-2">
                <AppWindow className="w-5 h-5 text-[#F97316]" />
                <div>
                  <h3 className="text-sm font-bold text-white">Запущенные окна Windows</h3>
                  <p className="text-[11px] text-zinc-400">Выберите процесс для мгновенного добавления в правила</p>
                </div>
              </div>
              <button
                onClick={() => setIsRunningWindowsModalOpen(false)}
                className="text-zinc-500 hover:text-zinc-300 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-2 max-h-[360px] overflow-y-auto pr-1">
              {RUNNING_WINDOWS_SAMPLE.map((win) => {
                const isAlreadyAdded = rules.some(
                  (r) => r.processName.toLowerCase() === win.processName.toLowerCase() && r.enabled
                );
                return (
                  <div
                    key={win.pid}
                    className="p-3 bg-[#1E1E22] border border-[#2A2A30] rounded-xl flex items-center justify-between gap-3 hover:border-zinc-500/50 transition-colors"
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <div className="w-8 h-8 rounded-lg bg-[#27272D] flex items-center justify-center shrink-0">
                        <AppIcon type={win.iconType} />
                      </div>
                      <div className="min-w-0">
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-semibold text-white truncate">{win.processName}</span>
                          <span className="text-[10px] font-mono text-zinc-500 px-1.5 py-0.2 rounded bg-[#161618]">
                            PID: {win.pid}
                          </span>
                        </div>
                        <div className="text-[11px] text-zinc-400 truncate mt-0.5">{win.title}</div>
                      </div>
                    </div>

                    <button
                      onClick={() => handleAddFromWindow(win)}
                      disabled={isAlreadyAdded}
                      className={`px-3 py-1.5 rounded-lg text-xs font-medium shrink-0 transition-colors ${
                        isAlreadyAdded
                          ? 'bg-zinc-800 text-zinc-500 cursor-not-allowed'
                          : 'bg-[#F97316] hover:bg-[#EA580C] text-black font-semibold cursor-pointer'
                      }`}
                    >
                      {isAlreadyAdded ? 'Уже в правилах' : 'Добавить'}
                    </button>
                  </div>
                );
              })}
            </div>

            <div className="flex justify-end pt-2 border-t border-[#2A2A30]">
              <button
                onClick={() => setIsRunningWindowsModalOpen(false)}
                className="px-4 py-1.5 bg-[#1E1E22] hover:bg-[#25252B] text-zinc-300 rounded-lg text-xs cursor-pointer"
              >
                Закрыть
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 3: Изменить путь / маску */}
      {editingRule && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="w-full max-w-md bg-[#18181C] border border-[#2A2A30] rounded-xl shadow-2xl p-5 space-y-4">
            <div className="flex items-center justify-between border-b border-[#2A2A30] pb-3">
              <div className="flex items-center gap-2">
                <Edit3 className="w-4 h-4 text-[#F97316]" />
                <h3 className="text-sm font-bold text-white">Редактировать путь процесса</h3>
              </div>
              <button
                onClick={() => setEditingRule(null)}
                className="text-zinc-500 hover:text-zinc-300 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleEditRuleSubmit} className="space-y-4 text-xs">
              <div>
                <label className="block text-zinc-400 mb-1">Название приложения:</label>
                <input
                  type="text"
                  value={editingRule.processName.replace(/\.exe$/i, '')}
                  onChange={(e) => setEditingRule({ ...editingRule, processName: e.target.value.replace(/\.exe$/i, '') })}
                  className="w-full bg-[#121214] border border-[#2A2A30] focus:border-[#F97316] rounded-lg px-3 py-2 text-zinc-200 outline-none"
                />
              </div>

              <div>
                <label className="block text-zinc-400 mb-1">Путь или маска поиска:</label>
                <input
                  type="text"
                  value={editingRule.path}
                  onChange={(e) => setEditingRule({ ...editingRule, path: e.target.value })}
                  className="w-full bg-[#121214] border border-[#2A2A30] focus:border-[#F97316] rounded-lg px-3 py-2 text-zinc-200 outline-none font-mono"
                />
                <span className="text-[10px] text-zinc-500 mt-1 block">
                  Знак * означает любое количество символов в пути к .exe файлу.
                </span>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-[#2A2A30]">
                <button
                  type="button"
                  onClick={() => setEditingRule(null)}
                  className="px-3 py-1.5 bg-[#1E1E22] hover:bg-[#25252B] text-zinc-400 rounded-lg cursor-pointer"
                >
                  Отмена
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 bg-[#F97316] hover:bg-[#EA580C] text-black font-semibold rounded-lg cursor-pointer"
                >
                  Сохранить
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 4: Создать группу правил */}
      {isCreateGroupModalOpen && (
        <div className="fixed inset-0 bg-black/75 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="w-full max-w-lg bg-[#18181C] border border-[#2A2A30] rounded-xl shadow-2xl p-5 space-y-4 max-h-[92vh] overflow-y-auto">
            {/* Header */}
            <div className="flex items-center justify-between border-b border-[#2A2A30] pb-3">
              <div className="flex items-center gap-2.5">
                <div className="w-7 h-7 rounded-lg bg-[#F97316]/20 border border-[#F97316]/40 flex items-center justify-center text-[#F97316]">
                  <FolderPlus className="w-4 h-4 stroke-[2.5]" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-white">Создать группу приложений</h3>
                  <p className="text-[11px] text-zinc-400">
                    Объединение {selectedRuleIds.length} правил под единым тумблером и прокси
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsCreateGroupModalOpen(false)}
                className="text-zinc-500 hover:text-zinc-300 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleCreateGroupSubmit} className="space-y-4 text-xs">
              {/* Group Name Input */}
              <div className="space-y-1.5">
                <label className="block text-zinc-300 font-medium">
                  Название группы:
                </label>
                <input
                  type="text"
                  required
                  autoFocus
                  value={newGroupName}
                  onChange={(e) => setNewGroupName(e.target.value)}
                  placeholder="Например: Мессенджеры, Игры, Рабочие инструменты..."
                  className="w-full bg-[#121214] border border-[#2A2A30] focus:border-[#F97316] rounded-lg px-3 py-2 text-zinc-200 placeholder-zinc-500 outline-none transition-colors"
                />

                {/* Quick Name Presets */}
                <div className="flex flex-wrap items-center gap-1.5 pt-1">
                  <span className="text-[11px] text-zinc-500">Быстрые варианты:</span>
                  {['Связь и звонки', 'Мессенджеры', 'Рабочие инструменты', 'Браузеры', 'Игры'].map((preset) => (
                    <button
                      key={preset}
                      type="button"
                      onClick={() => setNewGroupName(preset)}
                      className="px-2 py-0.5 rounded bg-[#1E1E22] hover:bg-[#27272E] text-zinc-400 hover:text-white border border-[#2A2A30] text-[11px] transition-colors cursor-pointer"
                    >
                      {preset}
                    </button>
                  ))}
                </div>
              </div>

              {/* Selected Apps Preview */}
              <div className="space-y-1.5">
                <label className="block text-zinc-400 font-medium">
                  Входящие приложения ({selectedRuleIds.length}):
                </label>
                <div className="flex flex-wrap gap-2 p-2.5 bg-[#141416] border border-[#2A2A30] rounded-xl max-h-36 overflow-y-auto">
                  {selectedRuleIds.map((id) => {
                    const rule = rules.find((r) => r.id === id);
                    if (!rule) return null;
                    return (
                      <div
                        key={rule.id}
                        className="flex items-center gap-1.5 px-2.5 py-1 bg-[#1E1E22] border border-[#32323A] rounded-lg text-zinc-200"
                      >
                        <div className="w-4 h-4 rounded bg-[#27272D] flex items-center justify-center shrink-0">
                          <AppIcon type={rule.iconType} />
                        </div>
                        <span className="font-medium">{rule.processName}</span>
                        <button
                          type="button"
                          onClick={() => handleToggleRuleSelection(rule.id)}
                          className="text-zinc-500 hover:text-red-400 ml-1 transition-colors cursor-pointer"
                          title="Убрать из группы"
                        >
                          <X className="w-3 h-3" />
                        </button>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Common Proxy Selector */}
              <div className="space-y-1.5 relative create-group-proxy-container">
                <label className="block text-zinc-400 font-medium">
                  Маршрутизировать всю группу через:
                </label>
                <button
                  type="button"
                  onClick={() => setIsCreateGroupProxyDropdownOpen(!isCreateGroupProxyDropdownOpen)}
                  className="w-full flex items-center justify-between p-2.5 bg-[#141416] border border-[#2A2A30] hover:border-zinc-500/60 rounded-xl transition-colors cursor-pointer text-left"
                >
                  {(() => {
                    const p = AVAILABLE_PROXIES.find((x) => x.id === newGroupProxyId) || AVAILABLE_PROXIES[0];
                    return (
                      <div className="flex items-center gap-2.5">
                        <div className="w-7 h-7 rounded-lg bg-[#27272D] flex items-center justify-center shrink-0">
                          {p.type === 'VLESS' ? (
                            <Zap className="w-3.5 h-3.5 text-[#F97316]" />
                          ) : p.type === 'SOCKS5' ? (
                            <Shield className="w-3.5 h-3.5 text-sky-400" />
                          ) : (
                            <Globe className="w-3.5 h-3.5 text-zinc-400" />
                          )}
                        </div>
                        <div>
                          <div className="font-semibold text-zinc-100">{p.name}</div>
                          <div className="text-[11px] text-zinc-500 font-mono">{p.endpoint}</div>
                        </div>
                      </div>
                    );
                  })()}
                  <ChevronDown className="w-4 h-4 text-zinc-500" />
                </button>

                {isCreateGroupProxyDropdownOpen && (
                  <div className="absolute left-0 right-0 top-full mt-1.5 bg-[#1C1C20] border border-[#2A2A30] rounded-xl shadow-2xl p-1.5 z-40 space-y-1 animate-in fade-in zoom-in-95">
                    {AVAILABLE_PROXIES.map((p) => (
                      <button
                        key={p.id}
                        type="button"
                        onClick={() => {
                          setNewGroupProxyId(p.id);
                          setIsCreateGroupProxyDropdownOpen(false);
                        }}
                        className={`w-full flex items-center justify-between p-2 rounded-lg text-left transition-colors cursor-pointer ${
                          p.id === newGroupProxyId
                            ? 'bg-[#F97316]/15 text-white font-medium border border-[#F97316]/30'
                            : 'text-zinc-300 hover:bg-[#25252B]'
                        }`}
                      >
                        <div className="flex items-center gap-2">
                          {p.type === 'VLESS' ? (
                            <Zap className="w-3.5 h-3.5 text-[#F97316]" />
                          ) : p.type === 'SOCKS5' ? (
                            <Shield className="w-3.5 h-3.5 text-sky-400" />
                          ) : (
                            <Globe className="w-3.5 h-3.5 text-zinc-400" />
                          )}
                          <div>
                            <div className="font-medium">{p.name}</div>
                            <div className="text-[10px] text-zinc-500 font-mono">{p.endpoint}</div>
                          </div>
                        </div>
                        {p.id === newGroupProxyId && <Check className="w-3.5 h-3.5 text-[#F97316]" />}
                      </button>
                    ))}
                  </div>
                )}
              </div>

              {/* Informational tip */}
              <div className="p-3 bg-[#1E1E22] border border-[#2A2A30] rounded-xl flex items-start gap-2.5 text-zinc-400">
                <Info className="w-4 h-4 text-[#F97316] shrink-0 mt-0.5" />
                <span className="text-[11px] leading-relaxed">
                  Все правила группы можно будет отключить сразу одним общим тумблером, а также в любой момент разгруппировать обратно в отдельные правила.
                </span>
              </div>

              {/* Buttons */}
              <div className="flex items-center justify-end gap-2 pt-3 border-t border-[#2A2A30]">
                <button
                  type="button"
                  onClick={() => setIsCreateGroupModalOpen(false)}
                  className="px-3.5 py-1.5 bg-[#1E1E22] hover:bg-[#25252B] text-zinc-400 hover:text-white rounded-lg transition-colors cursor-pointer"
                >
                  Отмена
                </button>
                <button
                  type="submit"
                  disabled={!newGroupName.trim() || selectedRuleIds.length === 0}
                  className={`px-4 py-1.5 font-semibold rounded-lg shadow-sm transition-all cursor-pointer ${
                    newGroupName.trim() && selectedRuleIds.length > 0
                      ? 'bg-[#F97316] hover:bg-[#EA580C] text-black shadow-orange-500/20 active:scale-[0.98]'
                      : 'bg-zinc-800 text-zinc-500 cursor-not-allowed'
                  }`}
                >
                  Сгруппировать ({selectedRuleIds.length})
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Toast Notification Alert */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 bg-[#1E1E22] border border-[#3A3A44] text-zinc-200 text-xs px-4 py-2.5 rounded-lg shadow-xl z-50 flex items-center gap-2.5 animate-in slide-in-from-bottom-2">
          <div className="w-2 h-2 rounded-full bg-[#F97316]" />
          <span>{toastMessage}</span>
        </div>
      )}
    </div>
  );
}

// -------------------------------------------------------------
// Component: Single Application Rule Row
// -------------------------------------------------------------
interface RuleRowItemProps {
  rule: AppRule;
  onToggle: (id: string, e?: React.MouseEvent) => void;
  onOpenProxySelector: (id: string) => void;
  onOpenContextMenu: (id: string) => void;
  isContextMenuOpen: boolean;
  isProxySelectorOpen: boolean;
  onAssignProxy: (ruleId: string, proxyId: string) => void;
  onUpdateSetting: (ruleId: string, key: keyof AppRule, value: any) => void;
  onDelete: (ruleId: string) => void;
  onEdit: (rule: AppRule) => void;
  // Multi-selection & grouping props
  isSelectionMode?: boolean;
  isSelected?: boolean;
  onSelect?: (id: string) => void;
  isInGroup?: boolean;
  groupName?: string;
  onRemoveFromGroup?: (id: string) => void;
}

function RuleRowItem({
  rule,
  onToggle,
  onOpenProxySelector,
  onOpenContextMenu,
  isContextMenuOpen,
  isProxySelectorOpen,
  onAssignProxy,
  onUpdateSetting,
  onDelete,
  onEdit,
  isSelectionMode,
  isSelected,
  onSelect,
  isInGroup,
  groupName,
  onRemoveFromGroup,
}: RuleRowItemProps) {
  const currentProxy = AVAILABLE_PROXIES.find((p) => p.id === rule.proxyId) || AVAILABLE_PROXIES[0];

  return (
    <div
      className={`relative bg-[#1E1E22] hover:bg-[#232328] border border-[#2A2A30] rounded-xl px-4 py-3 transition-colors flex items-center justify-between gap-4 group ${
        !rule.enabled ? 'bg-[#1A1A1E]/80 border-[#25252A]' : ''
      }`}
    >
      {/* 1. LEFT ZONE: Checkbox Slot + Status Circle Slot + App Icon Slot + Process Name + Path + Child Badge */}
      {/* Fixed 310px width so Telemetry column starts at the exact same pixel across ALL rows */}
      <div className="w-[310px] shrink-0 flex items-center gap-3">
        {/* Multi-select Checkbox Slot (Fixed w-5 h-5 - exactly matches Chevron Slot in GroupRowItem) */}
        <div className="w-5 h-5 flex items-center justify-center shrink-0">
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              onSelect?.(rule.id);
            }}
            className={`w-4 h-4 rounded border transition-all flex items-center justify-center cursor-pointer ${
              isSelected
                ? 'bg-[#F97316] border-[#F97316] text-black shadow-sm shadow-orange-500/30 opacity-100'
                : isSelectionMode
                ? 'border-[#3A3A44] bg-[#161618] hover:border-zinc-400 opacity-100'
                : 'border-[#3A3A44] bg-[#161618] hover:border-zinc-400 opacity-0 group-hover:opacity-100'
            }`}
            title={isSelected ? 'Снять выбор' : 'Выбрать правило для группировки'}
          >
            {isSelected && <Check className="w-3 h-3 stroke-[3]" />}
          </button>
        </div>

        {/* Status Indicator Circle Slot (Fixed w-3 flex items-center justify-center) */}
        <div className="w-3 flex items-center justify-center shrink-0">
          {rule.status === 'active' && rule.enabled ? (
            <div
              className="w-2.5 h-2.5 rounded-full bg-[#22C55E] shadow-[0_0_8px_rgba(34,197,94,0.7)]"
              title="Стабильно активен, трафик идет через прокси"
            />
          ) : rule.status === 'blocked' && rule.enabled ? (
            <div
              className="w-2.5 h-2.5 rounded-full bg-[#EF4444] shadow-[0_0_8px_rgba(239,68,68,0.8)] animate-pulse"
              title={rule.errorReason || 'Трафик заблокирован Kill Switch'}
            />
          ) : (
            <div
              className="w-2.5 h-2.5 rounded-full bg-[#52525B]"
              title="Правило отключено"
            />
          )}
        </div>

        {/* 32x32 App Icon in rounded square */}
        <div className="w-8 h-8 rounded-lg bg-[#27272D] border border-[#34343B] flex items-center justify-center shrink-0 shadow-inner">
          <AppIcon type={rule.iconType} />
        </div>

        {/* Name and path/mask */}
        <div className="flex flex-col min-w-0 pr-2">
          <div className="flex items-center gap-2">
            <span
              className={`text-sm font-semibold truncate ${
                rule.enabled ? 'text-zinc-100' : 'text-zinc-400'
              }`}
            >
              {rule.processName.replace(/\.exe$/i, '')}
            </span>

            {/* Blocked Badge if Kill Switch triggered */}
            {rule.status === 'blocked' && rule.enabled && (
              <span className="text-[10px] font-medium px-1.5 py-0.2 rounded bg-red-500/15 text-red-400 border border-red-500/30 shrink-0">
                Трафик заблокирован
              </span>
            )}
          </div>

          <div className="flex items-center gap-1.5 text-xs text-zinc-400 font-mono mt-0.5 truncate">
            <span className="truncate">{rule.path}</span>
            {rule.proxyChildren && (
              <span
                className="inline-flex items-center gap-0.5 text-[10px] text-zinc-400 font-sans px-1 py-0.2 bg-[#27272D] rounded shrink-0 border border-[#32323A]"
                title="Включено проксирование дочерних процессов"
              >
                <GitBranch className="w-2.5 h-2.5 text-[#F97316]" />
                <span>+дочерние</span>
              </span>
            )}
          </div>
        </div>
      </div>

      {/* 2. CENTER ZONE: Live Network Telemetry (Fixed 240px width for pixel-perfect vertical alignment) */}
      <div className="w-[240px] shrink-0 flex flex-col justify-center pl-1">
        {rule.enabled && rule.status === 'active' ? (
          <div className="space-y-0.5">
            <div className="flex items-center gap-2 text-xs font-mono text-zinc-200">
              <span className="text-zinc-400 shrink-0">{rule.threads} потоков</span>
              <span className="text-zinc-600">·</span>
              <span className="text-emerald-400">{rule.downSpeed}</span>
              <span className="text-sky-400">{rule.upSpeed}</span>
            </div>
            <div className="text-[11px] font-mono text-zinc-500">
              {rule.totalVolume} за сессию
            </div>
          </div>
        ) : rule.enabled && rule.status === 'blocked' ? (
          <div className="space-y-0.5">
            <div className="text-xs font-mono text-red-400 font-medium truncate">
              0 потоков · Сбой соединения SOCKS5
            </div>
            <div className="text-[11px] font-mono text-zinc-500 truncate">
              Таймаут шлюза 127.0.0.1:1080 (Kill Switch)
            </div>
          </div>
        ) : (
          <div className="space-y-0.5">
            <div className="text-xs font-mono text-zinc-500">
              Не в сети · —
            </div>
            <div className="text-[11px] font-mono text-zinc-600">
              Прямой обход прокси
            </div>
          </div>
        )}
      </div>

      {/* 3. RIGHT-CENTER ZONE: Compact Interactive Proxy Selector Badge (omitted for grouped rules) */}
      <div className="flex-1 flex justify-end shrink-0 proxy-selector-container">
        {!isInGroup && (
          <button
            onClick={(e) => {
              e.stopPropagation();
              onOpenProxySelector(isProxySelectorOpen ? '' : rule.id);
            }}
            className={`proxy-selector-trigger flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border text-xs font-mono transition-colors cursor-pointer ${
              rule.status === 'blocked' && rule.enabled
                ? 'bg-red-500/10 border-red-500/30 text-red-300 hover:bg-red-500/20'
                : 'bg-[#18181C] hover:bg-[#24242A] border-[#2A2A30] text-zinc-300 hover:text-white'
            }`}
          >
            {currentProxy.type === 'VLESS' ? (
              <Zap className="w-3.5 h-3.5 text-[#F97316] shrink-0" />
            ) : currentProxy.type === 'SOCKS5' ? (
              <Shield className="w-3.5 h-3.5 text-sky-400 shrink-0" />
            ) : (
              <Globe className="w-3.5 h-3.5 text-zinc-400 shrink-0" />
            )}

            <span className="font-semibold">{currentProxy.type}</span>
            <span className="text-zinc-500 hidden sm:inline">·</span>
            <span className="text-zinc-400 hidden sm:inline">{currentProxy.endpoint}</span>
            <ChevronDown className="w-3 h-3 text-zinc-500 ml-0.5" />
          </button>
        )}

        {/* Proxy Selector Popover (only accessible if NOT in a group) */}
        {!isInGroup && isProxySelectorOpen && (
          <div className="absolute right-0 top-full mt-1.5 w-64 bg-[#1C1C20] border border-[#2A2A30] rounded-xl shadow-2xl p-1.5 z-40 text-xs animate-in fade-in zoom-in-95">
            <div className="px-2.5 py-1 text-[10px] font-semibold text-zinc-400 uppercase tracking-wider">
              Назначить прокси
            </div>
            <div className="space-y-0.5 mt-1">
              {AVAILABLE_PROXIES.map((p) => (
                <button
                  key={p.id}
                  onClick={(e) => {
                    e.stopPropagation();
                    onAssignProxy(rule.id, p.id);
                  }}
                  className={`w-full flex items-center justify-between px-2.5 py-2 rounded-lg text-left transition-colors cursor-pointer ${
                    p.id === rule.proxyId
                      ? 'bg-[#F97316]/15 text-white font-medium border border-[#F97316]/30'
                      : 'text-zinc-300 hover:bg-[#25252B]'
                  }`}
                >
                  <div className="flex items-center gap-2 min-w-0">
                    {p.type === 'VLESS' ? (
                      <Zap className="w-3.5 h-3.5 text-[#F97316]" />
                    ) : p.type === 'SOCKS5' ? (
                      <Shield className="w-3.5 h-3.5 text-sky-400" />
                    ) : (
                      <Globe className="w-3.5 h-3.5 text-zinc-400" />
                    )}
                    <div className="truncate">
                      <div className="font-medium truncate">{p.name}</div>
                      <div className="text-[10px] text-zinc-500 font-mono">{p.endpoint}</div>
                    </div>
                  </div>

                  <div className="flex items-center gap-1.5 shrink-0 ml-2">
                    {p.status === 'online' ? (
                      <span className="text-[10px] text-emerald-400 font-mono">{p.pingMs}ms</span>
                    ) : (
                      <span className="text-[10px] text-red-400 font-mono">Offline</span>
                    )}
                    {p.id === rule.proxyId && <Check className="w-3.5 h-3.5 text-[#F97316]" />}
                  </div>
                </button>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* 4. RIGHT ZONE: Switch Toggle (Orange #F97316) + Context Menu ⋯ */}
      <div className="flex items-center gap-3 shrink-0">
        {/* Modern Switch-Тумблер */}
        <button
          type="button"
          role="switch"
          aria-checked={rule.enabled}
          onClick={(e) => onToggle(rule.id, e)}
          className={`w-11 h-6 rounded-full transition-colors relative focus:outline-none p-0.5 cursor-pointer ${
            rule.enabled ? 'bg-[#F97316]' : 'bg-[#2E2E36]'
          }`}
          title={rule.enabled ? 'Выключить правило' : 'Включить правило'}
        >
          <div
            className={`w-5 h-5 rounded-full bg-white shadow-md transform transition-transform duration-200 ${
              rule.enabled ? 'translate-x-5' : 'translate-x-0'
            }`}
          />
        </button>

        {/* Context Menu ⋯ Trigger */}
        <div className="relative context-menu-container">
          <button
            onClick={(e) => {
              e.stopPropagation();
              onOpenContextMenu(isContextMenuOpen ? '' : rule.id);
            }}
            className="context-menu-trigger w-8 h-8 rounded-lg flex items-center justify-center text-zinc-400 hover:text-white hover:bg-[#2A2A32] transition-colors cursor-pointer"
            title="Дополнительные параметры правила"
          >
            <MoreHorizontal className="w-4 h-4" />
          </button>

          {/* Context Menu Popover */}
          {isContextMenuOpen && (
            <div className="absolute right-0 top-full mt-1.5 w-64 bg-[#1E1E22] border border-[#2A2A30] rounded-xl shadow-2xl p-2 z-50 text-xs animate-in fade-in zoom-in-95 space-y-1">
              <div className="px-2 py-1 text-[10px] font-semibold text-zinc-500 uppercase tracking-wider">
                Параметры правила
              </div>

              {/* If inside group: option to remove from group */}
              {isInGroup && onRemoveFromGroup && (
                <>
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      onRemoveFromGroup(rule.id);
                    }}
                    className="w-full flex items-center gap-2 px-2.5 py-1.5 rounded-lg text-left hover:bg-[#282830] transition-colors text-amber-300 hover:text-amber-200 cursor-pointer"
                  >
                    <FolderMinus className="w-3.5 h-3.5 text-amber-400" />
                    <span>Исключить из группы {groupName ? `«${groupName}»` : ''}</span>
                  </button>
                  <div className="h-[1px] bg-[#2A2A30] my-1" />
                </>
              )}

              {/* Setting 1: Проксировать дочерние процессы */}
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  onUpdateSetting(rule.id, 'proxyChildren', !rule.proxyChildren);
                }}
                className="w-full flex items-center justify-between px-2.5 py-2 rounded-lg text-left hover:bg-[#282830] transition-colors text-zinc-200 cursor-pointer"
              >
                <span>Проксировать дочерние процессы</span>
                {rule.proxyChildren ? (
                  <CheckSquare className="w-4 h-4 text-[#F97316]" />
                ) : (
                  <Square className="w-4 h-4 text-zinc-600" />
                )}
              </button>

              {/* Setting 2: Kill Switch */}
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  onUpdateSetting(rule.id, 'killSwitch', !rule.killSwitch);
                }}
                className="w-full flex items-center justify-between px-2.5 py-2 rounded-lg text-left hover:bg-[#282830] transition-colors text-zinc-200 cursor-pointer"
              >
                <div className="flex flex-col">
                  <span>Kill Switch</span>
                  <span className="text-[10px] text-zinc-500">Блокировать при сбое</span>
                </div>
                {rule.killSwitch ? (
                  <CheckSquare className="w-4 h-4 text-[#F97316]" />
                ) : (
                  <Square className="w-4 h-4 text-zinc-600" />
                )}
              </button>

              {/* Setting 3: Protocol Switcher */}
              <div className="px-2.5 py-1.5 space-y-1 bg-[#161618] rounded-lg">
                <span className="text-[10px] text-zinc-400 font-medium block">Протокол маршрутизации:</span>
                <div className="grid grid-cols-2 gap-1">
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      onUpdateSetting(rule.id, 'protocol', 'TCP_UDP');
                    }}
                    className={`py-1 px-1.5 rounded text-[11px] text-center transition-colors cursor-pointer ${
                      rule.protocol === 'TCP_UDP'
                        ? 'bg-[#F97316] text-black font-semibold'
                        : 'text-zinc-400 hover:text-zinc-200'
                    }`}
                  >
                    TCP + UDP
                  </button>
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      onUpdateSetting(rule.id, 'protocol', 'TCP_ONLY');
                    }}
                    className={`py-1 px-1.5 rounded text-[11px] text-center transition-colors cursor-pointer ${
                      rule.protocol === 'TCP_ONLY'
                        ? 'bg-[#F97316] text-black font-semibold'
                        : 'text-zinc-400 hover:text-zinc-200'
                    }`}
                  >
                    Только TCP
                  </button>
                </div>
              </div>

              {/* Divider */}
              <div className="h-[1px] bg-[#2A2A30] my-1" />

              {/* Action 4: Изменить путь / маску */}
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  onEdit(rule);
                }}
                className="w-full flex items-center gap-2 px-2.5 py-1.5 rounded-lg text-left hover:bg-[#282830] transition-colors text-zinc-300 cursor-pointer"
              >
                <Edit3 className="w-3.5 h-3.5 text-zinc-400" />
                <span>Изменить путь / маску...</span>
              </button>

              {/* Action 5: Удалить правило (Красным цветом) */}
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  onDelete(rule.id);
                }}
                className="w-full flex items-center gap-2 px-2.5 py-1.5 rounded-lg text-left hover:bg-red-500/15 transition-colors text-red-400 hover:text-red-300 cursor-pointer"
              >
                <Trash2 className="w-3.5 h-3.5 text-red-400" />
                <span>Удалить правило</span>
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

// -------------------------------------------------------------
// Component: Group of Application Rules
// -------------------------------------------------------------
interface GroupRowItemProps {
  group: RuleGroup;
  members: AppRule[];
  onToggleGroup: (groupId: string, e?: React.MouseEvent) => void;
  onToggleCollapse: (groupId: string) => void;
  onUngroup: (groupId: string) => void;
  onAssignGroupProxy: (groupId: string, proxyId: string) => void;
  onDeleteGroup: (groupId: string) => void;
  isContextMenuOpen: boolean;
  isProxySelectorOpen: boolean;
  onOpenContextMenu: (id: string) => void;
  onOpenProxySelector: (id: string) => void;
  // Child rule item callbacks
  onToggleRule: (id: string, e?: React.MouseEvent) => void;
  onOpenRuleProxySelector: (id: string) => void;
  onOpenRuleContextMenu: (id: string) => void;
  openContextMenuRuleId: string | null;
  openProxySelectorRuleId: string | null;
  onAssignRuleProxy: (ruleId: string, proxyId: string) => void;
  onUpdateRuleSetting: (ruleId: string, key: keyof AppRule, value: any) => void;
  onDeleteRule: (ruleId: string) => void;
  onEditRule: (rule: AppRule) => void;
  onRemoveRuleFromGroup: (ruleId: string) => void;
  isSelectionMode?: boolean;
  selectedRuleIds: string[];
  onSelectRule: (ruleId: string) => void;
}

function GroupRowItem({
  group,
  members,
  onToggleGroup,
  onToggleCollapse,
  onUngroup,
  onAssignGroupProxy,
  onDeleteGroup,
  isContextMenuOpen,
  isProxySelectorOpen,
  onOpenContextMenu,
  onOpenProxySelector,
  onToggleRule,
  onOpenRuleProxySelector,
  onOpenRuleContextMenu,
  openContextMenuRuleId,
  openProxySelectorRuleId,
  onAssignRuleProxy,
  onUpdateRuleSetting,
  onDeleteRule,
  onEditRule,
  onRemoveRuleFromGroup,
  isSelectionMode,
  selectedRuleIds,
  onSelectRule,
}: GroupRowItemProps) {
  const currentProxy = AVAILABLE_PROXIES.find((p) => p.id === group.proxyId) || AVAILABLE_PROXIES[0];
  const activeMembers = members.filter((m) => m.enabled && m.status === 'active');
  const totalThreads = activeMembers.reduce((acc, m) => acc + m.threads, 0);

  return (
    <div className="space-y-1.5">
      {/* Group Header Card */}
      <div
        onClick={() => onToggleCollapse(group.id)}
        className={`relative bg-[#1C1C20] hover:bg-[#202025] border border-[#2F2F37] hover:border-[#F97316]/40 rounded-xl px-4 py-3 transition-all flex items-center justify-between gap-4 group cursor-pointer shadow-sm ${
          !group.enabled ? 'bg-[#18181B]/80 border-[#24242A] opacity-75' : ''
        }`}
      >
        {/* 1. LEFT ZONE: Chevron Slot + Status Circle Slot + Folder Icon Slot + Group Name + Member Icon Stack */}
        <div className="w-[310px] shrink-0 flex items-center gap-3">
          {/* Collapse/Expand Chevron Slot (Fixed w-5 h-5 - exactly matches Checkbox Slot in RuleRowItem) */}
          <div className="w-5 h-5 flex items-center justify-center shrink-0">
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                onToggleCollapse(group.id);
              }}
              className="w-5 h-5 flex items-center justify-center text-zinc-400 hover:text-white transition-colors cursor-pointer"
              title={group.isCollapsed ? 'Развернуть группу' : 'Свернуть группу'}
            >
              <ChevronRight
                className={`w-4 h-4 transition-transform duration-200 ${
                  !group.isCollapsed ? 'rotate-90 text-[#F97316]' : 'text-zinc-500'
                }`}
              />
            </button>
          </div>

          {/* Group Status Indicator Circle Slot (Fixed w-3 flex items-center justify-center - exactly same column as rules) */}
          <div className="w-3 flex items-center justify-center shrink-0">
            {group.enabled ? (
              <div
                className="w-2.5 h-2.5 rounded-full bg-[#22C55E] shadow-[0_0_8px_rgba(34,197,94,0.7)]"
                title="Группа активна: правила включены"
              />
            ) : (
              <div
                className="w-2.5 h-2.5 rounded-full bg-[#52525B]"
                title="Группа отключена: все правила выключены"
              />
            )}
          </div>

          {/* 32x32 Folder Icon with Orange Tint (Exact same w-8 h-8 slot as App Icon) */}
          <div className="w-8 h-8 rounded-lg bg-[#24242A] border border-[#34343E] flex items-center justify-center text-[#F97316] shrink-0 shadow-sm">
            <Folder className="w-4 h-4 fill-[#F97316]/20 stroke-[#F97316] stroke-[2]" />
          </div>

          {/* Group Name & Member Apps Info */}
          <div className="flex flex-col min-w-0 pr-2">
            <div className="flex items-center gap-2">
              <span
                className={`text-sm font-semibold truncate ${
                  group.enabled ? 'text-zinc-100' : 'text-zinc-400'
                }`}
              >
                {group.name}
              </span>
            </div>

            {/* Subtitle with overlapping mini app icons */}
            <div className="flex items-center gap-2 mt-0.5">
              {/* Mini App Icon Stack */}
              <div className="flex items-center -space-x-1.5 shrink-0">
                {members.slice(0, 4).map((member) => (
                  <div
                    key={member.id}
                    className="w-4 h-4 rounded-full bg-[#27272D] border border-[#34343B] flex items-center justify-center overflow-hidden"
                    title={member.processName}
                  >
                    <div className="scale-75 origin-center">
                      <AppIcon type={member.iconType} />
                    </div>
                  </div>
                ))}
              </div>
              <span className="text-[11px] text-zinc-400 truncate">
                {members.map((m) => m.processName).join(', ')}
              </span>
            </div>
          </div>
        </div>

        {/* 2. CENTER ZONE: Aggregate Live Telemetry (Same 240px width) */}
        <div className="w-[240px] shrink-0 flex flex-col justify-center pl-1">
          {group.enabled && activeMembers.length > 0 ? (
            <div className="space-y-0.5">
              <div className="flex items-center gap-2 text-xs font-mono text-zinc-200">
                <span className="text-zinc-400 shrink-0">{totalThreads} потоков</span>
                <span className="text-zinc-600">·</span>
                <span className="text-emerald-400">↓ 2,6 МБ/с</span>
                <span className="text-sky-400">↑ 132 КБ/с</span>
              </div>
              <div className="text-[11px] font-mono text-zinc-500">
                {members.length} приложений суммарно
              </div>
            </div>
          ) : (
            <div className="space-y-0.5">
              <div className="text-xs font-mono text-zinc-500">
                Группа отключена · 0 потоков
              </div>
              <div className="text-[11px] font-mono text-zinc-600">
                Все приложения группы работают напрямую
              </div>
            </div>
          )}
        </div>

        {/* 3. RIGHT-CENTER ZONE: Common Proxy Selector for the whole Group */}
        <div className="flex-1 flex justify-end shrink-0 group-proxy-selector-container">
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              onOpenProxySelector(isProxySelectorOpen ? '' : group.id);
            }}
            className="group-proxy-selector-trigger flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border text-xs font-mono transition-colors cursor-pointer bg-[#18181C] hover:bg-[#24242A] border-[#2A2A30] text-zinc-300 hover:text-white"
            title="Сменить прокси для всех приложений группы"
          >
            {currentProxy.type === 'VLESS' ? (
              <Zap className="w-3.5 h-3.5 text-[#F97316] shrink-0" />
            ) : currentProxy.type === 'SOCKS5' ? (
              <Shield className="w-3.5 h-3.5 text-sky-400 shrink-0" />
            ) : (
              <Globe className="w-3.5 h-3.5 text-zinc-400 shrink-0" />
            )}

            <span className="font-semibold">{currentProxy.type}</span>
            <span className="text-zinc-500 hidden sm:inline">·</span>
            <span className="text-zinc-400 hidden sm:inline">{currentProxy.endpoint}</span>
            <ChevronDown className="w-3 h-3 text-zinc-500 ml-0.5" />
          </button>

          {/* Group Proxy Selector Popover */}
          {isProxySelectorOpen && (
            <div
              onClick={(e) => e.stopPropagation()}
              className="absolute right-0 top-full mt-1.5 w-64 bg-[#1C1C20] border border-[#2A2A30] rounded-xl shadow-2xl p-1.5 z-40 text-xs animate-in fade-in zoom-in-95"
            >
              <div className="px-2.5 py-1 text-[10px] font-semibold text-zinc-400 uppercase tracking-wider">
                Назначить прокси группе
              </div>
              <div className="space-y-0.5 mt-1">
                {AVAILABLE_PROXIES.map((p) => (
                  <button
                    key={p.id}
                    onClick={(e) => {
                      e.stopPropagation();
                      onAssignGroupProxy(group.id, p.id);
                    }}
                    className={`w-full flex items-center justify-between px-2.5 py-2 rounded-lg text-left transition-colors cursor-pointer ${
                      p.id === group.proxyId
                        ? 'bg-[#F97316]/15 text-white font-medium border border-[#F97316]/30'
                        : 'text-zinc-300 hover:bg-[#25252B]'
                    }`}
                  >
                    <div className="flex items-center gap-2 min-w-0">
                      {p.type === 'VLESS' ? (
                        <Zap className="w-3.5 h-3.5 text-[#F97316]" />
                      ) : p.type === 'SOCKS5' ? (
                        <Shield className="w-3.5 h-3.5 text-sky-400" />
                      ) : (
                        <Globe className="w-3.5 h-3.5 text-zinc-400" />
                      )}
                      <div className="truncate">
                        <div className="font-medium truncate">{p.name}</div>
                        <div className="text-[10px] text-zinc-500 font-mono">{p.endpoint}</div>
                      </div>
                    </div>

                    <div className="flex items-center gap-1.5 shrink-0 ml-2">
                      {p.status === 'online' ? (
                        <span className="text-[10px] text-emerald-400 font-mono">{p.pingMs}ms</span>
                      ) : (
                        <span className="text-[10px] text-red-400 font-mono">Offline</span>
                      )}
                      {p.id === group.proxyId && <Check className="w-3.5 h-3.5 text-[#F97316]" />}
                    </div>
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* 4. RIGHT ZONE: Master Switch + Context Menu ⋯ (Ungroup is inside the ⋯ menu) */}
        <div className="flex items-center gap-3 shrink-0">
          {/* Master Switch Toggle for the whole Group */}
          <button
            type="button"
            role="switch"
            aria-checked={group.enabled}
            onClick={(e) => onToggleGroup(group.id, e)}
            className={`w-11 h-6 rounded-full transition-colors relative focus:outline-none p-0.5 cursor-pointer ${
              group.enabled ? 'bg-[#F97316]' : 'bg-[#2E2E36]'
            }`}
            title={group.enabled ? 'Отключить всю группу правил' : 'Включить всю группу правил'}
          >
            <div
              className={`w-5 h-5 rounded-full bg-white shadow-md transform transition-transform duration-200 ${
                group.enabled ? 'translate-x-5' : 'translate-x-0'
              }`}
            />
          </button>

          {/* Context Menu ⋯ Trigger */}
          <div className="relative group-context-menu-container">
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                onOpenContextMenu(isContextMenuOpen ? '' : group.id);
              }}
              className="group-context-menu-trigger w-8 h-8 rounded-lg flex items-center justify-center text-zinc-400 hover:text-white hover:bg-[#2A2A32] transition-colors cursor-pointer"
              title="Параметры группы"
            >
              <MoreHorizontal className="w-4 h-4" />
            </button>

            {/* Context Menu Popover */}
            {isContextMenuOpen && (
              <div
                onClick={(e) => e.stopPropagation()}
                className="absolute right-0 top-full mt-1.5 w-60 bg-[#1E1E22] border border-[#2A2A30] rounded-xl shadow-2xl p-2 z-50 text-xs animate-in fade-in zoom-in-95 space-y-1"
              >
                <div className="px-2 py-1 text-[10px] font-semibold text-zinc-500 uppercase tracking-wider">
                  Действия с группой
                </div>

                {/* Action 1: Разгруппировать */}
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    onUngroup(group.id);
                  }}
                  className="w-full flex items-center gap-2 px-2.5 py-1.5 rounded-lg text-left hover:bg-[#282830] transition-colors text-[#F97316] hover:text-orange-300 font-medium cursor-pointer"
                >
                  <FolderMinus className="w-3.5 h-3.5 text-[#F97316]" />
                  <span>Разгруппировать правила</span>
                </button>

                {/* Action 2: Свернуть / Развернуть */}
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    onToggleCollapse(group.id);
                  }}
                  className="w-full flex items-center gap-2 px-2.5 py-1.5 rounded-lg text-left hover:bg-[#282830] transition-colors text-zinc-300 cursor-pointer"
                >
                  <ChevronDown className="w-3.5 h-3.5 text-zinc-400" />
                  <span>{group.isCollapsed ? 'Развернуть список' : 'Свернуть список'}</span>
                </button>

                <div className="h-[1px] bg-[#2A2A30] my-1" />

                {/* Action 3: Удалить группу */}
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    onDeleteGroup(group.id);
                  }}
                  className="w-full flex items-center gap-2 px-2.5 py-1.5 rounded-lg text-left hover:bg-red-500/15 transition-colors text-red-400 hover:text-red-300 cursor-pointer"
                >
                  <Trash2 className="w-3.5 h-3.5 text-red-400" />
                  <span>Удалить группу и правила</span>
                </button>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Expanded Nested Member Rules List */}
      {!group.isCollapsed && (
        <div className="ml-5 pl-3 border-l-2 border-[#2A2A30] space-y-2 pt-1 pb-1 animate-in fade-in duration-150">
          {members.map((rule) => (
            <RuleRowItem
              key={rule.id}
              rule={rule}
              onToggle={onToggleRule}
              onOpenProxySelector={onOpenRuleProxySelector}
              onOpenContextMenu={onOpenRuleContextMenu}
              isContextMenuOpen={openContextMenuRuleId === rule.id}
              isProxySelectorOpen={openProxySelectorRuleId === rule.id}
              onAssignProxy={onAssignRuleProxy}
              onUpdateSetting={onUpdateRuleSetting}
              onDelete={onDeleteRule}
              onEdit={onEditRule}
              isInGroup={true}
              groupName={group.name}
              onRemoveFromGroup={onRemoveRuleFromGroup}
              isSelectionMode={isSelectionMode}
              isSelected={selectedRuleIds.includes(rule.id)}
              onSelect={onSelectRule}
            />
          ))}
        </div>
      )}
    </div>
  );
}

// -------------------------------------------------------------
// Component: Distinct Application SVGs / Icons
// -------------------------------------------------------------
function AppIcon({ type }: { type: AppRule['iconType'] }) {
  switch (type) {
    case 'discord':
      return (
        <svg viewBox="0 0 24 24" className="w-5 h-5 fill-[#5865F2]">
          <path d="M20.317 4.37a19.791 19.791 0 0 0-4.885-1.515.074.074 0 0 0-.079.037c-.21.375-.444.864-.608 1.25a18.27 18.27 0 0 0-5.487 0 12.64 12.64 0 0 0-.617-1.25.077.077 0 0 0-.079-.037A19.736 19.736 0 0 0 3.677 4.37a.07.07 0 0 0-.032.027C.533 9.046-.32 13.58.099 18.057a.082.082 0 0 0 .031.057 19.9 19.9 0 0 0 5.993 3.03.078.078 0 0 0 .084-.028c.462-.63.874-1.295 1.226-1.994.021-.041.001-.09-.041-.106a13.107 13.107 0 0 1-1.872-.892.077.077 0 0 1-.008-.128 10.2 10.2 0 0 0 .372-.292.074.074 0 0 1 .077-.01c3.929 1.793 8.18 1.793 12.061 0a.074.074 0 0 1 .078.01c.12.098.246.198.373.292a.077.077 0 0 1-.006.127 12.299 12.299 0 0 1-1.873.894.077.077 0 0 0-.041.107c.36.698.772 1.362 1.225 1.993a.076.076 0 0 0 .084.028 19.839 19.839 0 0 0 6.002-3.03.077.077 0 0 0 .032-.054c.5-5.177-.838-9.674-3.549-13.66a.061.061 0 0 0-.031-.028zM8.02 15.33c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.956-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.956 2.418-2.157 2.418zm7.975 0c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.955-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.946 2.418-2.157 2.418z" />
        </svg>
      );
    case 'cursor':
      return (
        <svg viewBox="0 0 24 24" className="w-5 h-5 fill-none stroke-white stroke-2" strokeLinecap="round" strokeLinejoin="round">
          <path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5" />
        </svg>
      );
    case 'telegram':
      return (
        <svg viewBox="0 0 24 24" className="w-5 h-5 fill-[#229ED9]">
          <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm4.64 6.8c-.15 1.58-.8 5.42-1.13 7.19-.14.75-.42 1-.68 1.03-.58.05-1.02-.38-1.58-.75-.88-.58-1.38-.94-2.23-1.5-.99-.65-.35-1.01.22-1.59.15-.15 2.71-2.48 2.76-2.69a.2.2 0 0 0-.05-.18c-.06-.05-.14-.03-.21-.02-.09.02-1.49.95-4.22 2.79-.4.27-.76.41-1.08.4-.36-.01-1.04-.2-1.55-.37-.63-.2-1.12-.31-1.08-.66.02-.18.27-.36.74-.55 2.92-1.27 4.86-2.11 5.83-2.52 2.77-1.18 3.35-1.38 3.73-1.39.08 0 .27.02.39.12.1.08.13.19.14.27-.01.06.01.24 0 .38z" />
        </svg>
      );
    case 'spotify':
      return (
        <svg viewBox="0 0 24 24" className="w-5 h-5 fill-[#1DB954]">
          <path d="M12 2C6.477 2 2 6.477 2 12s4.477 10 10 10 10-4.477 10-10S17.523 2 12 2zm4.586 14.424a.623.623 0 0 1-.857.207c-2.348-1.435-5.304-1.76-8.785-.964a.624.624 0 1 1-.277-1.217c3.808-.87 7.076-.496 9.712 1.117a.623.623 0 0 1 .207.857zm1.225-2.723a.78.78 0 0 1-1.072.257c-2.687-1.652-6.785-2.131-9.965-1.166a.78.78 0 0 1-.453-1.492c3.632-1.102 8.147-.568 11.233 1.328a.78.78 0 0 1 .257 1.073zm.105-2.835C14.692 8.95 9.375 8.775 6.297 9.71a.936.936 0 1 1-.548-1.791c3.535-1.073 9.404-.866 13.14 1.353a.936.936 0 1 1-.973 1.6z" />
        </svg>
      );
    case 'chrome':
      return (
        <svg viewBox="0 0 24 24" className="w-5 h-5">
          <circle cx="12" cy="12" r="10" fill="#EA4335" />
          <circle cx="12" cy="12" r="4.5" fill="#FFFFFF" />
          <circle cx="12" cy="12" r="3.2" fill="#4285F4" />
          <path d="M12 7.5h8.5A10 10 0 0 1 17.5 19L12 12z" fill="#FBBC05" opacity="0.9" />
          <path d="M17.5 19A10 10 0 0 1 3.5 17L8.5 12z" fill="#34A853" opacity="0.95" />
        </svg>
      );
    case 'steam':
      return (
        <svg viewBox="0 0 24 24" className="w-5 h-5 fill-none stroke-[#66C0F4] stroke-2" strokeLinecap="round" strokeLinejoin="round">
          <circle cx="12" cy="12" r="10" />
          <circle cx="8.5" cy="15.5" r="2.5" />
          <circle cx="15.5" cy="8.5" r="3.5" />
          <path d="M12 12l-3.5 3.5" />
        </svg>
      );
    case 'obsidian':
      return (
        <div className="w-5 h-5 rounded bg-purple-600 flex items-center justify-center font-bold text-[10px] text-white">
          O
        </div>
      );
    case 'code':
      return (
        <svg viewBox="0 0 24 24" className="w-5 h-5 fill-[#007ACC]">
          <path d="M18.5 2h-13A1.5 1.5 0 0 0 4 3.5v17A1.5 1.5 0 0 0 5.5 22h13a1.5 1.5 0 0 0 1.5-1.5v-17A1.5 1.5 0 0 0 18.5 2zm-9 14.5L5.5 13l4-3.5 1 1-2.5 2.5 2.5 2.5-1 1zm5 0l-1-1 2.5-2.5-2.5-2.5 1-1 4 3.5-4 3.5z" />
        </svg>
      );
    default:
      return <FolderOpen className="w-4 h-4 text-zinc-400" />;
  }
}
